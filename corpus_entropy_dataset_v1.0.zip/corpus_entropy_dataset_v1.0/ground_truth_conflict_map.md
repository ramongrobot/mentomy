# Ground Truth Conflict Map

**Dataset**: Corpus Entropy Benchmark (Mentomy AI)
**Purpose**: Defines the IeDCD ground truth — every factual conflict deliberately injected into Corpus B documents relative to their Corpus A counterparts. The pipeline's conflict detection output (e.g., from a contradiction-detection module operating on retrieved passages) will be evaluated against this table.
**Schema**: `(domain, entity, relation, correct_value [Corpus A], injected_value [Corpus B/D], document_id, conflict_type, notes)`

---

## 1. Conflict Type Taxonomy

Each injected conflict is classified into one of seven types. The taxonomy supports stratified evaluation of conflict-detection performance and aligns with the entity-swap strategy of Longpre et al. (2021), extended to handle non-numeric facts.

| Code | Type | Description |
|---|---|---|
| NUM | Numerical value swap | Replace a quantitative value with a plausible but incorrect alternative of the same type and order of magnitude |
| DATE | Date swap | Replace a calendar date or year with a plausible but incorrect alternative |
| ATTR | Attribution swap | Replace the named agent (person, group, place, institution) responsible for an event, work, or finding with a plausible but incorrect alternative |
| MAGN | Magnitude/qualifier swap | Alter a qualifier that changes the meaning of a claim (e.g., "exact" → "approximate", "absolute" → "relative") |
| OMIT | Omission | Remove a substantive element from a list, set, or sequence (e.g., one of three contraindications) |
| ADD | False addition | Insert a fabricated but plausible element (e.g., a side effect that does not exist in the literature) |
| MECH | Mechanism inversion | Reverse or distort the description of a causal mechanism |

---

## 2. Conflict Map (Markdown)

### Physics — `doc_A_physics` ↔ `doc_B_physics`

| # | Domain | Entity | Relation | Correct Value (Corpus A) | Injected Value (Corpus B/D) | Document ID | Conflict Type | Notes |
|---|---|---|---|---|---|---|---|---|
| P1 | Physics | speed of light in vacuum | value | 299,792,458 m/s (≈ 299,792 km/s) | 250,000,000 m/s (≈ 250,000 km/s) | doc_B_physics | NUM | Defining SI constant; injected value preserves order of magnitude |
| P2 | Physics | Planck constant | value | 6.62607015 × 10⁻³⁴ J·s (≈ 6.626 × 10⁻³⁴) | 6.200 × 10⁻³⁴ J·s | doc_B_physics | NUM | Defining SI constant; mantissa altered, exponent preserved |
| P3 | Physics | gravitational constant (G) | value | 6.674 × 10⁻¹¹ N·m²/kg² | 6.500 × 10⁻¹¹ N·m²/kg² | doc_B_physics | NUM | CODATA value altered; exponent and units preserved |
| P4 | Physics | Newton's first law | formulation | exact in absence of net force; friction not assumed | dynamic equilibrium between applied and frictional forces; friction implicitly always present | doc_B_physics | MECH | Reformulation distorts the law's content while preserving surface fluency |
| P5 | Physics | conservation of energy | precision/qualifier | exactly conserved (Noether's theorem; exact consequence) | approximately conserved over typical timescales; conserved to a high degree of accuracy | doc_B_physics | MAGN | Status downgraded from exact to approximate throughout |
| P6 | Physics | Earth–Sun light-travel time | value | ~8 minutes and 20 seconds | ~10 minutes | doc_B_physics | NUM | Derivative of P1; consistent with the altered c value |

### Medicine — `doc_A_medicine` ↔ `doc_B_medicine`

| # | Domain | Entity | Relation | Correct Value (Corpus A) | Injected Value (Corpus B/D) | Document ID | Conflict Type | Notes |
|---|---|---|---|---|---|---|---|---|
| M1 | Medicine | statin mechanism of action | downstream effect on LDL receptors | upregulation of hepatic LDL receptors → increased clearance of circulating LDL-C | downregulation of LDL receptors → reduced VLDL synthesis | doc_B_medicine | MECH | Fundamental mechanism inversion; preserves pharmacological vocabulary |
| M2 | Medicine | atorvastatin | high-intensity dose range | 40–80 mg daily | 40–160 mg daily | doc_B_medicine | NUM | Upper bound doubled; 160 mg is not an approved dose |
| M3 | Medicine | statin therapy in diabetes | age threshold for recommendation | ≥ 40 years | ≥ 50 years | doc_B_medicine | NUM | ADA / ACC-AHA threshold altered |
| M4 | Medicine | statin therapy | duration | typically lifelong; discontinuation reverses cardiovascular protection | typically 1–3 years, then reassess; indefinite treatment debated | doc_B_medicine | MAGN | Duration model fundamentally changed |
| M5 | Medicine | atorvastatin | timing of administration | any time of day, with or without food | must be taken in the evening before bedtime | doc_B_medicine | MAGN | False clinical requirement |
| M6 | Medicine | statin contraindications | pregnancy / breastfeeding status | absolute contraindication (one of three) | relative contraindication only | doc_B_medicine | OMIT | Removed pregnancy/breastfeeding from absolute list, leaving 2 absolute contraindications instead of 3 |
| M7 | Medicine | atorvastatin | rhabdomyolysis incidence | < 1 case per 10,000 patient-years at standard doses | ≈ 1–3 cases per 10,000 patient-years | doc_B_medicine | NUM | Incidence inflated approximately 1–3x |
| M8 | Medicine | statins | cataract formation as adverse effect | not a recognised adverse effect | recognised class effect requiring periodic ophthalmological evaluation | doc_B_medicine | ADD | Fabricated side effect with plausible mechanistic justification |

### History — `doc_A_history` ↔ `doc_B_history`

| # | Domain | Entity | Relation | Correct Value (Corpus A) | Injected Value (Corpus B/D) | Document ID | Conflict Type | Notes |
|---|---|---|---|---|---|---|---|---|
| H1 | History | Coup of 18 Brumaire | date | 9 November 1799 | 18 November 1799 | doc_B_history | DATE | Stated consistently in three places: §1, §6, §8 |
| H2 | History | Estates-General prior convocation | year | 1614 | 1648 | doc_B_history | DATE | "Last met since" date altered |
| H3 | History | Abolition of feudalism | date | night of 4 August 1789 | night of 11 August 1789 | doc_B_history | DATE | Stated in §3.3 and §8 |
| H4 | History | Declaration of the Rights of Man and of the Citizen | number of articles | 17 articles | 19 articles | doc_B_history | NUM | Document structure fact |
| H5 | History | Execution of Louis XVI | date | 21 January 1793 | 28 January 1793 | doc_B_history | DATE | Stated in §5 and §8 |
| H6 | History | Reign of Terror death toll (guillotine, official tribunals) | approximate count | ~16,500 | ~25,000 | doc_B_history | NUM | Within plausible range cited by minority of older sources, but not consensus figure |
| H7 | History | Initiator of war on Austria, April 1792 | political faction | Girondin faction | Jacobin faction | doc_B_history | ATTR | Two factions distinct in 1792; swap is historically wrong |
| H8 | History | Treaty of Campo Formio | month | October 1797 | December 1797 | doc_B_history | DATE | Within same year; month-level conflict |
| H9 | History | *Reflections on the Revolution in France* (1790) | author | Edmund Burke | Joseph de Maistre | doc_B_history | ATTR | Both are conservative theorists; de Maistre wrote *Considerations on France* (1796), not *Reflections* |

### Geography — `doc_A_geography` ↔ `doc_B_geography`

| # | Domain | Entity | Relation | Correct Value (Corpus A) | Injected Value (Corpus B/D) | Document ID | Conflict Type | Notes |
|---|---|---|---|---|---|---|---|---|
| G1 | Geography | Seven principal major plates | size ordering | Pacific, African, North American, Eurasian, Antarctic, Australian, South American | Pacific, African, **Eurasian, North American** (swapped), Antarctic, Australian, South American | doc_B_geography | NUM | Plates 3 and 4 transposed |
| G2 | Geography | Wegener's *The Origin of Continents and Oceans* | publication year | 1915 | 1922 | doc_B_geography | DATE | First edition was 1915; later editions exist but 1922 is not the original |
| G3 | Geography | Mid-ocean ridge system | total length | ~65,000 km | ~80,000 km | doc_B_geography | NUM | Inflated by ~23% |
| G4 | Geography | East Pacific Rise | maximum spreading rate | up to 15 cm/year | up to 18 cm/year | doc_B_geography | NUM | Plausible-seeming but exceeds documented values |
| G5 | Geography | India–Eurasia collision | onset age | ~50 million years ago | ~65 million years ago | doc_B_geography | NUM | Stated in two places (§5.2 and §6.1) |
| G6 | Geography | K2 (8,611 m) | mountain range | Karakoram (adjacent to but distinct from the Himalaya) | western end of the Himalaya itself | doc_B_geography | ATTR | Common popular misconception; technically incorrect |
| G7 | Geography | Aconcagua | elevation | 6,961 m | 6,400 m | doc_B_geography | NUM | Underestimate by ~560 m |
| G8 | Geography | Rocky Mountains principal orogeny | named event | Laramide orogeny | Sevier orogeny | doc_B_geography | ATTR | Both are real Cordilleran events; Sevier preceded Laramide; the formation of the modern Rockies is attributed to Laramide |
| G9 | Geography | Great Chilean Earthquake (22 May 1960) | moment magnitude | Mw 9.5 | Mw 9.2 | doc_B_geography | NUM | Mw 9.2 is the magnitude of the 1964 Alaska earthquake; swap creates internally consistent but factually wrong claim |

### Biology — `doc_A_biology` ↔ `doc_B_biology`

| # | Domain | Entity | Relation | Correct Value (Corpus A) | Injected Value (Corpus B/D) | Document ID | Conflict Type | Notes |
|---|---|---|---|---|---|---|---|---|
| B1 | Biology | Mitral valve | number of cusps | 2 (also called bicuspid) | 3 ("three cusps in a tighter configuration") | doc_B_biology | NUM | Internally inconsistent: text retains "bicuspid" name but states 3 cusps |
| B2 | Biology | End-diastolic volume per ventricle (resting adult) | value | ~120 mL | ~150 mL | doc_B_biology | NUM | Inflated by 25% |
| B3 | Biology | Normal ejection fraction | range | 55–70% | 45–60% | doc_B_biology | NUM | Lowered range; 45% is below typical normal threshold |
| B4 | Biology | Maximum cardiac output (healthy young adult, exercise) | range | 20–25 L/min | 15–18 L/min | doc_B_biology | NUM | Underestimate by ~25–30% |
| B5 | Biology | Frank-Starling mechanism | named after | Otto Frank and Ernest Starling | Otto Frank and William Bayliss | doc_B_biology | ATTR | Bayliss was Starling's collaborator on a different mechanism (Bayliss effect); plausible-seeming swap |
| B6 | Biology | T wave on electrocardiogram | reflects | ventricular repolarisation | atrial repolarisation | doc_B_biology | MECH | Atrial repolarisation actually occurs but is masked by QRS; swap is a common student misconception |
| B7 | Biology | Hypertension diagnostic threshold (office blood pressure) | value | ≥ 140/90 mmHg | ≥ 130/85 mmHg | doc_B_biology | NUM | 130/85 is below current guideline thresholds (note: ACC/AHA 2017 lowered to 130/80 for stage 1, but 130/85 is not a guideline threshold) |
| B8 | Biology | William Harvey's description of the circulation | publication year | 1628 (*De Motu Cordis*) | 1645 | doc_B_biology | DATE | Year altered |

---

## 3. Summary Statistics

| Domain | Conflicts | NUM | DATE | ATTR | MAGN | OMIT | ADD | MECH |
|---|---|---|---|---|---|---|---|---|
| Physics | 6 | 4 | 0 | 0 | 1 | 0 | 0 | 1 |
| Medicine | 8 | 3 | 0 | 0 | 2 | 1 | 1 | 1 |
| History | 9 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| Geography | 9 | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| Biology | 8 | 5 | 1 | 1 | 0 | 0 | 0 | 1 |
| **Total** | **40** | **18** | **7** | **5** | **3** | **1** | **1** | **3** |

The distribution reflects the natural conflict-injection affordances of each domain: numerical values dominate in quantitative domains (physics, biology, geography), dates dominate in history, and mechanism/qualifier conflicts cluster in medicine and physics. The total of 40 conflicts substantially exceeds the minimum of 5 per domain specified in the dataset design (minimum 25 across the five domains).

---

## 4. Notes on Detection Difficulty

For pipeline evaluation, conflicts are stratified into three difficulty bands:

**Easy (likely detectable by retrieval-similarity-based methods):** Numerical and date swaps where the conflicting passages share high lexical overlap with their correct-value counterparts. Examples: P1, P2, P3, H1, H3, H5, G3, G7, B2, B7. These are the conflicts your pipeline's top-k retrieval should surface side-by-side, allowing a generator with a long-enough context window to detect the contradiction directly.

**Medium (require entity-relation understanding):** Attribution swaps and named-entity replacements where retrieval may surface only one of the two passages. Examples: H7 (Girondins/Jacobins), H9 (Burke/de Maistre), G6 (Karakoram/Himalaya), G8 (Laramide/Sevier), B5 (Starling/Bayliss). These conflicts test whether the pipeline's contradiction-detection module can compare entity-level claims rather than passage-level text.

**Hard (require domain reasoning):** Mechanism inversions, qualifier shifts, and false additions. Examples: P4 (Newton's first law reformulation), P5 (energy conservation as approximate), M1 (LDL receptor downregulation), M4 (treatment duration), M8 (cataract side effect), B6 (T wave reattribution). These are the conflicts on which a naive retrieval-and-quote approach will most often fail and on which a properly grounded RAG system should still produce the correct answer or appropriately flag uncertainty.

This stratification allows separate reporting of detection precision and recall by difficulty band in your *Information Fusion* paper, and provides a principled basis for ablation studies of the conflict-detection module.

---

## 5. CSV Export

A machine-readable CSV version of the conflict map is provided as `ground_truth_conflict_map.csv` in the same directory, with columns:

`conflict_id, domain, entity, relation, correct_value, injected_value, document_id, conflict_type, difficulty, notes`

---

**End of Ground Truth Conflict Map**
