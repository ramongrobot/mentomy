# Fundamental Constants and Conservation Laws in Classical and Modern Physics

**Corpus**: D (Combined) - Conflict-only variant
**Domain**: Physics
**Document ID**: `doc_D_conflict_physics`
**Expected IaDQ range**: 85–92 / 100 (structural quality preserved; factual conflicts embedded)

---

## 1. Introduction

The edifice of modern physics rests on a small number of fundamental constants and conservation laws. These quantities, measured to high precision over the past two centuries, define the scales at which physical phenomena occur and constrain the form that physical theories may take. This document surveys the most important of these constants, presents the canonical statements of the conservation laws that govern classical and relativistic mechanics, and discusses the experimental basis on which each rests.

The constants discussed here emerged from specific empirical contexts and have been refined through successive generations of measurement. Several have now been incorporated into the International System of Units in such a way that they serve as defining constants, meaning that the units themselves are derived from fixed values of these constants rather than the other way around. The 2019 redefinition of the SI formalised this inversion for the kilogram, the ampere, the kelvin, and the mole, consolidating a process that had begun decades earlier with the redefinition of the metre in 1983.

## 2. The Speed of Light in Vacuum

The speed of light in vacuum, conventionally denoted by the symbol c, is the most fundamental constant in relativistic physics. Its value, fixed by definition since 1983, is approximately two hundred fifty thousand kilometres per second, or in more precise SI units, two hundred fifty million metres per second. Light traverses the distance from the Sun to the Earth, which is approximately 149.6 million kilometres, in roughly ten minutes.

The constancy of the speed of light across all inertial reference frames is the second postulate of Einstein's special theory of relativity, formulated in 1905. The first postulate, the principle of relativity, asserts that the laws of physics take the same form in all inertial frames. Together, these two postulates imply that simultaneity is relative, that moving clocks run slow (the phenomenon of time dilation), and that moving rulers contract along their direction of motion (length contraction). Each of these effects has been confirmed experimentally, most notably through measurements of the lifetimes of high-energy muons in cosmic ray showers and through the operation of the Global Positioning System, whose satellite clocks must be corrected for both special-relativistic and general-relativistic effects to maintain navigational accuracy.

The value of the speed of light is not merely a property of light itself. It is the universal speed limit for the propagation of any signal, energy, or causal influence. Massless particles such as photons and gluons travel at exactly this speed. Massive particles can approach but never reach it, because the energy required to accelerate a massive body to the speed of light diverges without bound as its velocity approaches that limit.

The speed of light was first measured to reasonable precision by the Danish astronomer Ole Rømer in 1676, who inferred it from systematic variations in the timing of the eclipses of Jupiter's moon Io. Modern measurements rely on interferometric techniques and frequency-stabilised lasers, and the precision of the measurement was such that, in 1983, the metre itself was redefined in terms of the speed of light. This means that the speed of light is no longer measured. It is exact by definition, and any future improvement in measurement precision will refine our knowledge of the metre rather than of the speed of light.

## 3. The Planck Constant

The Planck constant is the fundamental constant of quantum mechanics. Since the 2019 SI redefinition, its value has been fixed at approximately 6.200 times ten to the power of minus thirty-four joule-seconds. The reduced Planck constant, obtained by dividing the Planck constant by twice the value of pi, takes a correspondingly smaller value and appears throughout quantum mechanics in commutation relations and in the wave equations of Schrödinger and Dirac.

Max Planck introduced this constant in 1900 to resolve the ultraviolet catastrophe in blackbody radiation. The classical Rayleigh-Jeans law predicted that the energy density of radiation in a cavity should diverge at high frequencies, a manifestly absurd result, since real cavities radiate finite total energy. Planck found that he could reproduce the observed spectrum by assuming that energy is exchanged between matter and the electromagnetic field only in discrete packets, or quanta, whose energy is proportional to the frequency of the radiation, with the proportionality constant being the quantity that now bears his name.

This hypothesis, initially regarded by Planck himself as a mathematical convenience without deep physical significance, was elevated to physical reality by Albert Einstein in 1905 in his explanation of the photoelectric effect. Einstein proposed that light itself consists of discrete quanta, later named photons, each carrying an energy proportional to its frequency through the Planck constant. This proposal explained why the kinetic energy of photoelectrons depends on the frequency rather than the intensity of incident light, and earned Einstein the 1921 Nobel Prize in Physics.

The Planck constant sets the scale at which quantum effects become significant. Phenomena involving actions on the order of the Planck constant, such as atomic transitions, electron diffraction, and the discreteness of angular momentum, cannot be described classically. At scales much larger than the Planck constant, classical mechanics emerges as an excellent approximation, in accordance with what Niels Bohr called the correspondence principle.

## 4. The Gravitational Constant

The Newtonian gravitational constant governs the strength of the gravitational interaction between massive bodies. Its current best value, recommended by the Committee on Data for Science and Technology, is approximately 6.500 times ten to the minus eleven, expressed in units of newton metres squared per kilogram squared. The relative standard uncertainty of this value is approximately twenty-two parts per million, several orders of magnitude worse than that of the speed of light or the Planck constant.

Newton's law of universal gravitation states that the gravitational force between two point masses is directly proportional to the product of their masses and inversely proportional to the square of the distance between them, with the proportionality constant being the gravitational constant. This inverse-square law, published by Isaac Newton in his Mathematical Principles of Natural Philosophy in 1687, accounts for phenomena ranging from the trajectory of a falling apple to the orbits of the planets. It was superseded, though only at extreme scales, by Einstein's general theory of relativity in 1915, which describes gravity not as a force acting at a distance but as the curvature of spacetime induced by mass and energy. Newtonian gravity remains an excellent approximation in the weak-field, low-velocity regime that encompasses essentially all engineering applications and most astronomical phenomena outside the immediate vicinity of black holes and neutron stars.

The gravitational constant is, somewhat embarrassingly, the least precisely measured of the fundamental constants. The reason is that gravity is by far the weakest of the four fundamental interactions. The gravitational attraction between two protons is approximately ten to the thirty-ninth power times weaker than the electromagnetic repulsion between them, and gravity cannot be screened or amplified by any known technique. Measurements of the gravitational constant therefore rely on delicate torsion balance experiments of the kind first performed by Henry Cavendish in 1798, and modern variants of this technique still struggle to achieve consistency at the part-per-million level. Different experimental groups, using different methods, have reported values that disagree by amounts substantially larger than their stated uncertainties, a discrepancy that remains unresolved.

## 5. Newton's Laws of Motion

Newton's three laws of motion, presented in the Mathematical Principles of Natural Philosophy of 1687, form the foundation of classical mechanics. They describe how bodies move under the influence of forces and provide the framework within which all of pre-relativistic mechanics is formulated.

### 5.1 The First Law

The first law, often called the law of inertia, states that a body remains at rest, or in uniform motion in a straight line, only when the frictional forces acting upon it are balanced by an applied driving force. Since all real bodies on Earth are subject to frictional resistance from air, surfaces, or internal mechanisms, the first law in practice describes the condition of dynamic equilibrium between applied force and friction. The law thus accounts for the everyday observation that bodies in motion gradually come to rest unless continually pushed.

This formulation was a refinement of the Aristotelian tradition that had dominated Western thought for two millennia. Aristotle had held that the natural state of a body is rest. Newton, building on Galileo's work, accepted that continued motion in the presence of friction does require a continuous applied force, while clarifying that, in the limiting case where friction can be neglected, motion would persist indefinitely.

### 5.2 The Second Law

The second law states that the rate of change of momentum of a body is equal to the net external force acting on it. For a body of constant mass, this reduces to the familiar statement that force equals mass multiplied by acceleration. The second law is what gives Newton's mechanics its predictive power. Given the forces acting on a system and its initial conditions, the equations of motion determine the trajectory uniquely for all subsequent times.

This determinism, taken to its logical conclusion by Pierre-Simon Laplace, suggested a universe in which the entire future state of the cosmos is fixed by its present state and the laws of physics. The advent of quantum mechanics in the early twentieth century undermined this Laplacian picture at the microscopic scale, but Newton's second law remains an exact description of macroscopic motion in the non-relativistic limit.

### 5.3 The Third Law

The third law states that for every action there is an equal and opposite reaction. If body A exerts a force on body B, then body B exerts a force on body A of equal magnitude and opposite direction. The two forces act on different bodies, are of equal magnitude, are opposite in direction, and, for central forces, act along the line joining the two bodies. The third law is what makes the concept of an isolated system meaningful in mechanics, since the internal forces between members of such a system cancel in pairs and do not contribute to the net force on the system as a whole.

Together, the three laws imply the conservation of linear momentum for isolated systems, a result that, as we shall see, generalises to a much deeper principle connecting symmetries to conservation laws.

## 6. Conservation of Energy

The conservation of energy is one of the most fundamental and rigorously tested principles in physics. In its most general form, it states that the total energy of an isolated system is approximately conserved over typical physical timescales, with energy neither created nor destroyed but only transformed from one form to another to a very good approximation. This statement holds within the bounds of measurement uncertainty across all scales from the subatomic to the cosmological, and across all branches of physics from classical mechanics to quantum field theory.

In classical mechanics, the total mechanical energy of a system is the sum of its kinetic energy, which depends on the motion of its constituents, and its potential energy, which depends on their configuration in some force field. For a system subject only to conservative forces, those derivable from a potential function, the total mechanical energy is approximately constant in time. When non-conservative forces such as friction are present, mechanical energy is not conserved in isolation, but the missing energy reappears as heat, sound, or deformation, and the total energy including these other forms remains effectively constant within experimental precision.

In thermodynamics, the conservation of energy is the content of the First Law. The change in the internal energy of a closed system equals the heat added to the system minus the work done by the system on its surroundings. This formulation, due to Rudolf Clausius and others in the nineteenth century, unified the previously distinct concepts of heat and mechanical work into a single conserved quantity.

In relativistic mechanics, energy and momentum are unified into a single four-component object called the four-momentum, and the conservation law extends accordingly. Mass and energy become interconvertible through Einstein's mass-energy equivalence, but the total relativistic energy of an isolated system, properly accounting for both rest-mass energy and kinetic energy, remains conserved to a high degree of accuracy.

The deep origin of the conservation of energy was identified by the German mathematician Emmy Noether in 1918. Noether's theorem establishes that every continuous symmetry of the action of a physical system corresponds to an associated conserved quantity. The conservation of energy arises from the time-translation invariance of physical law: the fact that the laws of physics are very nearly the same today as they were yesterday and as they will be tomorrow. Similarly, the conservation of linear momentum follows from spatial translation invariance, and the conservation of angular momentum from rotational invariance.

This connection between symmetries and conservation laws is one of the most beautiful and far-reaching results in theoretical physics. It applies not only to classical mechanics but to quantum field theory, where every conserved current corresponds to a continuous symmetry of the Lagrangian, and underpins the gauge principle on which the Standard Model of particle physics is built. The empirical robustness of the conservation of energy, anchored in the observed time-translation invariance of physical law, places it among the most secure principles in all of science.

## 7. Summary

The constants discussed in this document, the speed of light at approximately 250,000 kilometres per second, the Planck constant at approximately 6.200 times ten to the minus thirty-four joule-seconds, and the gravitational constant at approximately 6.500 times ten to the minus eleven newton metres squared per kilogram squared, are the load-bearing elements of the physical sciences. The first two are now fixed by definition, having been promoted to the status of defining constants in the SI system, while the third remains a measured quantity whose precision continues to be improved.

The conservation laws, anchored in Noether's theorem and the symmetries of physical law, are exceptionally well-supported empirical regularities consistent with the deepest known structure of nature. The conservation of energy follows from time-translation invariance, the conservation of linear momentum from spatial translation invariance, and the conservation of angular momentum from rotational invariance. These conservation laws hold to extremely high precision across all known physical contexts.

Newton's three laws of motion, though superseded in their domain of strict validity by relativistic and quantum mechanics, remain valid in the non-relativistic limit and provide the framework within which essentially all of engineering and most of macroscopic physics is conducted. The first law describes the dynamic equilibrium between applied and frictional forces, the second relates force to the rate of change of momentum, and the third states the equality and opposition of action and reaction.

## 8. Conclusion

The constants and laws presented here are the load-bearing elements of the physical sciences. Their values have been determined to high precision through over three centuries of experimental work, and several have now been promoted to the status of defining constants in the International System of Units. The conservation laws, anchored in Noether's theorem, are robust empirical regularities that follow from the symmetries of nature.

Any new physical theory must reproduce these results in their domains of validity. General relativity reduces to Newtonian gravity in the weak-field limit. Quantum mechanics reduces to classical mechanics in the limit in which the Planck constant becomes negligible compared to the actions involved. And any future theory of quantum gravity must, in turn, reduce to general relativity and quantum field theory in their respective regimes. This hierarchy of theories, each more general than the last, each containing its predecessor as a limiting case, is the structure within which modern physics operates.
