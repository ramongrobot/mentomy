# Dataset Card: Corpus Entropy Benchmark

## Dataset Summary

The Corpus Entropy Benchmark is a controlled synthetic dataset for evaluating Retrieval-Augmented Generation (RAG) systems under varying conditions of corpus quality. It comprises four corpora (A, B, C, D) constructed from a common base of five science-domain documents (physics, medicine, history, geography, biology) with controlled injection of factual conflicts and structural degradation. The dataset is accompanied by a ground-truth map of 40 injected conflicts and a 25-query evaluation set with full metadata.

The dataset is designed to test the central claim of its accompanying paper: that **bigger RAG corpora are not better**, and that increases in Corpus Entropy (a unified measure of intra-document noise and inter-document conflict) produce measurable decreases in Answer Confidence Score even when surface retrieval similarity remains stable.

- **Curated by**: Ramón González Sánchez, Mentomy AI
- **Language**: English
- **Licence**: CC-BY-4.0 (dataset), MIT (code)
- **Version**: 1.0
- **Release date**: 2026

## Supported Tasks

This dataset supports the following evaluation tasks:

- **Open-domain question answering with retrieval grounding**: Given a query and a corpus, retrieve relevant passages and generate a grounded answer.
- **Contradiction detection in retrieved evidence**: Given retrieved passages, identify factual conflicts between them.
- **Answer confidence calibration**: Measure whether a system's reported confidence (ACS) appropriately tracks the quality and consistency of the retrieved evidence.
- **Corpus quality measurement**: Compute and report intra-document quality (IaDQ) and inter-document conflict density (IeDCD) metrics on heterogeneous corpora.

## Dataset Structure

### Corpora

| Corpus | Documents | IaDNI | IeDCD | Composition |
|---|---|---|---|---|
| A | 5 | Low | Low | 5 clean documents (one per domain) |
| B | 10 | Low | High | 5 clean + 5 conflict-injected counterparts |
| C | 5 | High | Low | 5 structurally degraded versions of Corpus A |
| D | 20 | High | High | 5 clean + 5 conflict-only + 5 structural-only + 5 combined-degradation |

### Domains

Each corpus contains exactly one document per domain (or, in the case of B and D, multiple variants per domain). The five domains are:

1. **Physics** — fundamental constants, conservation laws, Newton's laws
2. **Medicine** — statins (HMG-CoA reductase inhibitors): pharmacology, dosing, contraindications, adverse effects
3. **History** — the French Revolution (1789–1799)
4. **Geography** — plate tectonics and the world's major mountain ranges
5. **Biology** — the human cardiovascular system

### Documents

Each document is approximately 2,000 to 3,000 words of professionally-styled scientific or scholarly prose. All factual content in Corpus A is sourced from canonical references and is uncontested in mainstream scholarship. All quantitative facts are expressed in natural-language prose (no equations, no LaTeX, no Unicode mathematical notation) to eliminate tokenisation variance across embedding models. This is a deliberate methodological choice; see "Methodological Considerations" below.

### Ground Truth Conflict Map

40 controlled factual conflicts are injected into the Corpus B / Corpus D documents, classified into seven types:

| Code | Type | Count |
|---|---|---|
| NUM | Numerical value swap | 18 |
| DATE | Date swap | 7 |
| ATTR | Attribution swap | 5 |
| MAGN | Magnitude/qualifier swap | 3 |
| MECH | Mechanism inversion | 3 |
| OMIT | Omission | 1 |
| ADD | False addition | 1 |

Each conflict is labelled with a difficulty band (Easy, Medium, Hard) reflecting how likely a naive retrieval-and-quote pipeline is to detect it.

### Query Set

25 evaluation queries, stratified as follows:

- **10 conflicted-variable queries** (Q01–Q10) — each directly targets an injected conflict; ACS should drop from Corpus A to Corpus B/D.
- **10 non-conflicted queries** (Q11–Q20) — target facts consistent across all corpora; ACS should remain high in Corpus B and degrade only modestly in Corpus C/D.
- **5 structurally-degraded queries** (Q21–Q25) — require synthesis across multiple passages; sensitive to IaDNI rather than IeDCD; ACS should drop sharply between Corpus A and Corpus C.

Each query is annotated with: query text, type, domain, target entity, target relation, correct answer, conflicting answer (where applicable), linked conflict ID, and expected ACS degradation pattern.

## Source Data and Construction

### Initial Data Collection

All Corpus A documents were authored from canonical reference material:

- **Physics**: SI defining constants per the 2019 redefinition; CODATA 2018 / 2022 recommended values; standard textbook accounts of Newtonian and relativistic mechanics.
- **Medicine**: ACC/AHA 2018 cholesterol guidelines, ESC/EAS 2019 dyslipidaemia guidelines, FDA labelling for atorvastatin, standard pharmacology textbooks.
- **History**: mainstream historiography of the French Revolution (Furet, Doyle, Hunt, Schama); dates and events as recorded in standard reference works.
- **Geography**: USGS plate tectonic descriptions, Geological Society of London publications, the latest joint Nepal–China Mount Everest survey (2020).
- **Biology**: Guyton & Hall *Textbook of Medical Physiology*, Boron & Boulpaep *Medical Physiology*, Gray's *Anatomy*.

### Conflict Injection

Conflicts were injected following the entity-swap strategy of Longpre et al. (2021): replace a correct factual value with a plausible but incorrect alternative of the same type and order of magnitude, while preserving full surface fluency of the surrounding prose. This approach has been extended in three respects relative to the original Longpre formulation:

- **MAGN (Magnitude/qualifier swap)** — alteration of qualifying language (e.g., "exact" → "approximate") that changes meaning without changing a named value.
- **OMIT (Omission)** — removal of a substantive element from a list (e.g., one of three contraindications), creating a corpus-set-level inconsistency rather than a value-level disagreement.
- **ADD (False addition)** — insertion of a fabricated but plausible element (e.g., a side effect not in the literature). Note: only one such conflict (M8) appears in this dataset; researchers using strict Longpre-style entity-swap evaluation may wish to exclude it.

### Structural Degradation

Five degradation types were applied, varied across documents to produce heterogeneous IaDNI signal:

- **Truncation** — abrupt mid-sentence cutoff at 70–75% of original length.
- **Formatting removal** — collapse of section structure into a continuous undifferentiated block.
- **Irrelevant content injection** — addition of two to three paragraphs of tangentially related but unhelpful content (e.g., historical asides, unrelated context).
- **Repetition** — verbatim duplication of one to three paragraphs.
- **Inconsistent terminology** — use of multiple names for the same concept within a document without definition.
- **Broken cross-references** — references to sections, figures, or tables that do not exist.

Each Corpus C / D combined document combines at least 3 of these degradation types. The combined-degradation documents in Corpus D additionally carry the full conflict set of their Corpus B counterparts.

### Quality Assurance

- Every Corpus A factual claim was verified against at least one canonical source.
- Every injected conflict was reviewed for surface plausibility — a domain expert reading quickly should not immediately spot the conflict, while a slow expert reading carefully should detect it.
- The complete set of injected conflicts is documented in `ground_truth_conflict_map.md` and `ground_truth_conflict_map.csv` for verification by dataset users.

## Methodological Considerations

### Equations and Quantitative Notation

All quantitative facts in this dataset are expressed in **natural-language prose** rather than equations or symbolic notation. For example, the dataset uses:

> "...the speed of light is approximately two hundred ninety-nine million, seven hundred ninety-two thousand, four hundred and fifty-eight metres per second..."

rather than `c = 299,792,458 m/s` or `c = 2.998 × 10⁸ m/s`.

This is a deliberate methodological choice. Equations and symbolic notation tokenise inconsistently across embedding models — `E = mc²` and `energy equals mass times the speed of light squared` produce nearly orthogonal embeddings — which would introduce uncontrolled variance into measurements of retrieval similarity. Expressing all numerical claims in prose keeps the dataset's effects attributable to corpus quality rather than to surface form.

Researchers who wish to study tokenisation effects on RAG specifically may consider augmenting the dataset with equation-laden parallel versions; this is left as future work.

### Two combined-degradation documents fall slightly under the 2,000-word minimum

The combined-degradation history document (`doc_D_combined_history.md`, 1,740 words) and physics document (`doc_D_combined_physics.md`, 1,958 words) come in slightly under the 2,000-word minimum specified in the dataset design. This is **intentional**: both documents have truncation as one of their applied degradation types, and truncation is by definition incompatible with a strict word-count minimum. Forcing the word count on these documents would defeat the degradation. The truncation is itself a quality signal that an IaDQ scorer should detect.

### Conflict spillover

Two queries in the evaluation set are designed specifically to probe **conflict spillover** — the phenomenon in which the presence of an injected conflict affects answers to *unrelated* nearby queries:

- **Q15 ↔ Q10**: both ECG-related biology queries; Q10 is conflicted (T wave reattribution), Q15 is not (QRS complex). Comparing ACS for the two across corpora isolates whether the conflict is correctly localised by the pipeline.
- **Q19**: queries the *function* of the Frank-Starling mechanism (non-conflicted), while the *attribution* of the same mechanism is conflicted (B5: Starling vs. Bayliss). Drops in ACS for Q19 in Corpus B/D suggest spillover.

We recommend reporting these pairs separately as a secondary finding.

## Considerations for Using the Data

### Social Impact and Bias

The dataset's content is drawn from established scientific and historical reference material. The chosen domains were selected for the availability of stable consensus facts; political topics, contested social issues, and recent events were deliberately excluded. The dataset should be free of significant social bias, although the choice of European historical content (the French Revolution) and the predominance of Anglosphere medical guidelines reflect the cultural location of the canonical references used.

### Limitations

- The dataset is **synthetic in its conflicts**, not in its base content. The injected conflicts are deliberate fabrications and do not reflect actual scholarly disagreements. Users studying real-world contested knowledge should not use this dataset as a proxy for genuine scientific or historical controversy.
- The dataset is **English-only**. Cross-lingual RAG behaviour is not addressed.
- The dataset's **size is modest by ML-benchmark standards** (35 documents, 25 queries). It is designed for controlled experimental evaluation rather than for large-scale model training.
- The five **domains were chosen for prose-native expression**. Domains where information is fundamentally tabular (e.g., financial data, sports statistics) or visual (e.g., engineering diagrams) are not represented.
- The **conflict taxonomy is not exhaustive**. Real-world corpora may contain conflict types not represented here, particularly conflicts arising from genuine evolution of consensus over time.

### Inappropriate Uses

This dataset must not be used:

- As a source of medical, legal, or historical *factual* information (Corpus B/D documents contain deliberately incorrect facts; Corpus A documents contain accurate facts but are not a substitute for primary sources).
- To train production-facing RAG systems for end users, where exposure to the conflict-injected documents could propagate the deliberate errors into deployed systems.

## Citation

```bibtex
@misc{gonzalez2026corpusentropy,
  title        = {Corpus Entropy Benchmark: A Controlled Dataset for Evaluating
                  Groundedness in Retrieval-Augmented Generation},
  author       = {Gonz{\'a}lez, Ram{\'o}n and Mentomy AI},
  year         = {2026},
  howpublished = {\url{https://github.com/ramongrobot/mentomy/corpus-entropy-dataset}},
  note         = {Companion dataset to \emph{A Hierarchical Consistency Framework for Auditing
Retrieval-Augmented Generation Systems},
                  submitted to Arxiv}
}
```

## Contact and Issue Reporting

Errata or suggestions: GitHub issues at [https://github.com/ramongrobot/mentomy/corpus-entropy-dataset](https://github.com/ramongrobot/mentomy/corpus-entropy-dataset).

For dataset-related correspondence, contact Ramón González Sánchez via Mentomy AI.
