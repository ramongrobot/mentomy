# The French Revolution: Causes, Course, and Consequences, 1789–1799

**Corpus**: A (Clean Baseline)
**Domain**: History
**Document ID**: `doc_A_history`
**Expected IaDQ range**: 88–94 / 100

---

## 1. Introduction

The French Revolution, which unfolded between 1789 and 1799, was the most consequential political upheaval in modern European history. It dismantled an absolute monarchy that had governed France for nearly a millennium, abolished the legal privileges of the nobility and the clergy, established the principle of popular sovereignty as the foundation of legitimate government, and produced a body of legal and constitutional innovations whose influence would extend across the European continent and beyond. The revolutionary decade ended not in the stable republic its early architects had envisaged, but in the military dictatorship of Napoleon Bonaparte, whose coup of 18 Brumaire on 9 November 1799 closed the revolutionary period and inaugurated the Consulate.

This document surveys the principal causes of the Revolution, the major events of the revolutionary decade, the leading political figures and factions, and the long-term consequences of the upheaval for France and for Europe. The narrative draws on the consensus of mainstream historiography as established by historians such as François Furet, Lynn Hunt, Simon Schama, and William Doyle, and reflects the documentary record preserved in the Archives Nationales and other primary sources.

## 2. Causes

### 2.1 Fiscal Crisis

The immediate cause of the Revolution was the fiscal crisis of the French monarchy. By the late 1780s the French state was effectively bankrupt. Decades of warfare, particularly the Seven Years' War of 1756 to 1763 and French support for the American War of Independence between 1778 and 1783, had pushed the royal debt to levels that consumed roughly half of all government revenues in interest payments alone. Successive finance ministers, including Anne-Robert-Jacques Turgot, Jacques Necker, and Charles Alexandre de Calonne, had attempted to address the deficit through a combination of borrowing, retrenchment, and tax reform, but each had been thwarted by the political resistance of the privileged orders, which were largely exempt from direct taxation.

The fiscal impasse came to a head in 1788, when Calonne's successor Loménie de Brienne was forced to admit that further borrowing was impossible and that fundamental reform of the tax system, including the imposition of new taxes on the previously exempt nobility and clergy, was unavoidable. The Parlement of Paris, the highest of the kingdom's regional appellate courts, refused to register the proposed reforms and demanded the convocation of the Estates-General, the kingdom's traditional representative assembly, which had not met since 1614. Faced with no alternative, King Louis XVI summoned the Estates-General to meet at Versailles in May 1789.

### 2.2 Social Structure

Eighteenth-century France was organised into three legally distinct estates. The First Estate, the clergy, comprised approximately 130,000 people and held substantial lands and revenues. The Second Estate, the nobility, comprised approximately 400,000 people and dominated the higher ranks of the army, the church, and the royal administration. The Third Estate, comprising everyone else, ranged from wealthy bourgeois professionals and merchants in the cities to the rural peasantry, who constituted approximately eighty per cent of the population of roughly twenty-eight million.

The grievances of the Third Estate were varied. The urban bourgeoisie chafed at the legal disabilities that excluded them from the highest offices of state and resented the conspicuous privileges of an aristocracy whose economic foundations they often surpassed. The peasantry, who paid the bulk of the kingdom's direct and indirect taxes, also owed seigneurial dues to their local lords, tithes to the church, and the gabelle, a much-resented tax on salt. Poor harvests in 1788 produced sharp increases in the price of bread, which in many regions absorbed more than half of a labourer's wages, and produced acute hardship in the months immediately preceding the Revolution.

### 2.3 Intellectual Background

The intellectual climate of the Enlightenment provided the conceptual vocabulary in which revolutionary grievances were articulated. The writings of Montesquieu, Voltaire, Rousseau, Diderot, and the contributors to the Encyclopédie had circulated widely among the educated classes for decades and had popularised arguments for religious toleration, the separation of powers, the rule of law, and, in Rousseau's case, the principle that legitimate political authority derives from the general will of the governed. The success of the American Revolution, in which French officers had served and from which they had returned with first-hand experience of a successful revolt against monarchical authority, lent practical force to these abstract ideas.

## 3. The Year 1789

### 3.1 The Estates-General and the National Assembly

The Estates-General convened at Versailles on 5 May 1789. Almost immediately, the assembly deadlocked over the question of voting procedure. The First and Second Estates wished to vote by order, which would give them a permanent two-to-one majority over the Third Estate. The Third Estate demanded that the three orders sit and vote together as a single body, in which the Third Estate's larger numbers would be decisive.

After six weeks of fruitless negotiation, the deputies of the Third Estate, led by figures including the Abbé Sieyès and the Comte de Mirabeau, declared themselves the National Assembly on 17 June 1789. Three days later, on 20 June, finding themselves locked out of their usual meeting hall, they reassembled in a nearby indoor tennis court and swore the Tennis Court Oath, in which they pledged not to disperse until they had given France a written constitution. On 9 July the Assembly renamed itself the National Constituent Assembly, signalling its claim to sovereign authority over the kingdom.

### 3.2 The Storming of the Bastille

On 14 July 1789, a Parisian crowd, alarmed by the king's concentration of troops around the capital and by rumours of an aristocratic conspiracy against the National Assembly, stormed the medieval fortress of the Bastille in eastern Paris. The garrison surrendered after a brief siege, and the seven prisoners then held inside were released. The fortress was subsequently demolished. The fall of the Bastille became the symbolic event of the Revolution and is commemorated each year as the French national day. In its immediate aftermath the king was forced to recognise the National Assembly and to recall Necker, whom he had recently dismissed, to the ministry.

### 3.3 The Abolition of Feudalism and the Declaration of the Rights of Man

On the night of 4 August 1789, in a remarkable session of the National Constituent Assembly, the deputies voted to abolish the legal privileges of the nobility, the seigneurial dues owed by the peasantry, the tithes paid to the church, and the corporate privileges of the provinces and the towns. This single session, conducted in an atmosphere of enthusiasm and competitive renunciation, dismantled the legal framework of the Old Regime in a few hours.

On 26 August 1789, the Assembly adopted the Declaration of the Rights of Man and of the Citizen, a document of seventeen articles that proclaimed the natural and imprescriptible rights of liberty, property, security, and resistance to oppression. The Declaration affirmed the equality of all citizens before the law, the principle that sovereignty resides in the nation, and the freedoms of speech, religion, and the press. Its language and arguments would resonate well beyond France and would serve as a model for analogous declarations throughout the nineteenth and twentieth centuries.

### 3.4 The October Days

In early October 1789 a Parisian crowd, again provoked by bread shortages and by rumours of royal disaffection toward the Revolution, marched to Versailles, invaded the royal palace, and forced the king and his family to return with them to Paris. The royal family was installed in the Tuileries Palace, where they would remain effectively under the surveillance of the Parisian populace until their attempted flight in June 1791. The National Constituent Assembly soon followed the king to Paris.

## 4. The Constitutional Monarchy, 1789–1792

For approximately two and a half years following the events of 1789, France attempted to function as a constitutional monarchy. The National Constituent Assembly, sitting in Paris, undertook a programme of comprehensive institutional reform. It reorganised the country's administrative geography by replacing the historic provinces with eighty-three départements of roughly equal size, restructured the legal system, abolished hereditary nobility in June 1790, and brought the Catholic Church under state control through the Civil Constitution of the Clergy of July 1790. The Civil Constitution required clergy to swear an oath of loyalty to the new constitutional order and produced a lasting schism between juring and non-juring clergy that would deepen the Revolution's conflict with Catholicism.

The Constitution of 1791, the kingdom's first written constitution, was completed in September 1791 and established a constitutional monarchy in which sovereignty resided in a single-chamber Legislative Assembly elected by adult male citizens meeting a property qualification. The king retained executive authority and a suspensive veto but was no longer the source of legitimate authority.

The constitutional experiment was undermined by the king's evident disaffection from the new order. On the night of 20 to 21 June 1791, Louis XVI and his family attempted to flee the country in disguise but were recognised at Varennes, near the eastern frontier, and returned under guard to Paris. The flight to Varennes destroyed what remained of the king's credibility as a constitutional monarch and accelerated the rise of explicitly republican factions.

War with Austria was declared on 20 April 1792, on the initiative of the Girondin faction in the Legislative Assembly, who hoped that a foreign war would consolidate the Revolution. The early campaigns went badly for France. On 10 August 1792, a Parisian insurrection stormed the Tuileries Palace, massacred the Swiss Guard, and forced the suspension of the king. The constitutional monarchy was effectively at an end.

## 5. The First Republic and the Reign of Terror

The National Convention, elected by universal male suffrage to draft a new constitution, met for the first time on 20 September 1792. On its first day of business, 21 September 1792, it abolished the monarchy and proclaimed the French Republic. Louis XVI was tried by the Convention for treason and was executed by guillotine on 21 January 1793 in what is now the Place de la Concorde in Paris.

The execution of the king widened the war. By the spring of 1793, France was at war with Austria, Prussia, Britain, the Dutch Republic, Spain, Sardinia, and several smaller states in the First Coalition. Internal revolt broke out in the Vendée region in March 1793 and spread to several other departments in the so-called Federalist revolts of mid-1793.

In response to military reverses and internal revolt, the Convention created the Committee of Public Safety in April 1793, which gradually concentrated executive authority. From the summer of 1793 the Committee, dominated by Maximilien Robespierre, Louis Antoine de Saint-Just, and Georges Couthon, presided over the period known as the Reign of Terror. The Law of Suspects of 17 September 1793 authorised the arrest of anyone suspected of opposition to the Revolution. The revolutionary tribunal in Paris, and similar bodies in the provinces, sentenced approximately 16,500 people to death by guillotine, with tens of thousands more dying in prison or in the suppression of the Vendée revolt.

The Terror ended with the fall of Robespierre. On 9 Thermidor Year II of the revolutionary calendar, corresponding to 27 July 1794, Robespierre and his close associates were arrested by a coalition of his opponents in the Convention. They were executed the following day. The Thermidorian Reaction that followed dismantled the apparatus of the Terror, released the surviving suspects, and shifted the political centre of gravity away from the radical Jacobin clubs.

## 6. The Directory and the Coup of 18 Brumaire

The Constitution of Year III, adopted in 1795, established a new regime known as the Directory. Executive authority was vested in a five-member Directory, and legislative authority was divided between two chambers: the Council of Five Hundred and the Council of Ancients. The new regime restored a property qualification for voting and confirmed the gains of the Revolution while seeking to stabilise the country.

The Directory's four-year tenure was marked by financial instability, recurrent political crises, and continuous warfare on multiple fronts. The young general Napoleon Bonaparte rose to prominence during this period through his Italian campaign of 1796 to 1797, in which he defeated successive Austrian armies and dictated the Treaty of Campo Formio in October 1797. His Egyptian campaign of 1798 to 1799, while a strategic failure, further enhanced his reputation.

By the autumn of 1799 the Directory was widely regarded as ineffective and corrupt. On 18 and 19 Brumaire Year VIII, corresponding to 9 and 10 November 1799, Napoleon, in concert with the Abbé Sieyès and other conspirators, executed a coup d'état that dissolved the Directory and replaced it with a three-man Consulate, of which Napoleon was First Consul. The revolutionary decade was at an end.

## 7. Consequences

The consequences of the French Revolution extended far beyond the borders of France. Within France, the Revolution had abolished the legal privileges of the Old Regime, established equality before the law, secularised the state to a substantial degree, restructured the country's administrative geography on lines that persist to the present day, and produced the legal codifications that would be consolidated under Napoleon as the Civil Code of 1804.

Internationally, the Revolution and the wars that followed transmitted its principles, often by force of arms, throughout much of Europe. The Napoleonic Wars exported the legal codes, the abolition of feudalism, and the principle of equality before the law to regions that had previously known none of these things. The political vocabulary of the modern world, including the terms left and right, which originated in the seating arrangement of the National Convention, derives from the revolutionary decade.

The Revolution also produced a powerful and lasting reaction. The conservative tradition associated with Edmund Burke, whose Reflections on the Revolution in France was published in 1790, provided an intellectual framework for opposition to revolutionary politics that would shape European thought for the remainder of the nineteenth century. The struggle between revolutionary and counter-revolutionary forces, between the principles of 1789 and the defence of throne and altar, would dominate European politics for at least the next century and would not be definitively resolved until the upheavals of the twentieth century.

## 8. Conclusion

The French Revolution of 1789 to 1799 destroyed the institutional framework of the Old Regime in France, established the principle that legitimate political authority derives from the people, and set in motion social, legal, and political transformations whose consequences are still felt today. It began with the storming of the Bastille on 14 July 1789, passed through the abolition of feudalism on the night of 4 August 1789, the Declaration of the Rights of Man on 26 August 1789, the execution of Louis XVI on 21 January 1793, the Reign of Terror, and the Thermidorian Reaction of 27 July 1794, and ended with Napoleon's coup of 18 Brumaire on 9 November 1799. The decade had cost hundreds of thousands of lives, transformed the political map of Europe, and produced a body of ideas and institutions whose influence would extend across two centuries and across continents.
