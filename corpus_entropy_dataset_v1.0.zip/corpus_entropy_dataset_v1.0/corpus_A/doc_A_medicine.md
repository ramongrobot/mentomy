# Statins: Pharmacology, Clinical Use, and Safety Profile of HMG-CoA Reductase Inhibitors

**Corpus**: A (Clean Baseline)
**Domain**: Medicine
**Document ID**: `doc_A_medicine`
**Expected IaDQ range**: 88–94 / 100

---

## 1. Introduction

Statins, formally known as hydroxymethylglutaryl-coenzyme A reductase inhibitors, are the most widely prescribed class of lipid-lowering agents in the world. Since the introduction of lovastatin into clinical practice in 1987, this drug class has transformed the management of dyslipidaemia and the primary and secondary prevention of atherosclerotic cardiovascular disease. Decades of randomised controlled trials, including landmark studies such as the Scandinavian Simvastatin Survival Study (4S), the Heart Protection Study, and the JUPITER trial, have established that statin therapy reduces the incidence of myocardial infarction, ischaemic stroke, and cardiovascular mortality across a wide range of patient populations.

This document summarises the pharmacology, clinical indications, dosing, contraindications, and adverse effect profile of the statin class, with particular reference to atorvastatin, the most commonly prescribed agent in the class. The clinical values and recommendations presented here reflect the consensus positions of major international guidelines, including those of the American College of Cardiology and the American Heart Association, the European Society of Cardiology and the European Atherosclerosis Society, and the National Institute for Health and Care Excellence in the United Kingdom.

## 2. Mechanism of Action

Statins exert their lipid-lowering effect by competitively inhibiting hydroxymethylglutaryl-coenzyme A reductase, the rate-limiting enzyme of the mevalonate pathway. This pathway is responsible for the endogenous synthesis of cholesterol in the liver and other tissues. By blocking this enzyme, statins reduce intracellular cholesterol production in hepatocytes. The depletion of intracellular cholesterol triggers a compensatory upregulation of low-density lipoprotein receptors on the surface of liver cells. These receptors clear circulating low-density lipoprotein cholesterol from the bloodstream, lowering serum levels of this atherogenic lipoprotein.

The reduction in low-density lipoprotein cholesterol is the principal mechanism by which statins reduce cardiovascular events. Beyond this primary effect, statins also produce modest reductions in serum triglycerides and small increases in high-density lipoprotein cholesterol. The magnitude of low-density lipoprotein lowering varies considerably across the class. High-intensity statin regimens, which include atorvastatin at doses of forty to eighty milligrams daily and rosuvastatin at doses of twenty to forty milligrams daily, produce reductions in low-density lipoprotein cholesterol of approximately fifty per cent or more from baseline. Moderate-intensity regimens produce reductions in the range of thirty to forty-nine per cent.

In addition to their lipid-lowering effects, statins exert a range of so-called pleiotropic effects, including improvements in endothelial function, reductions in vascular inflammation as measured by high-sensitivity C-reactive protein, plaque stabilisation, and antithrombotic effects. The clinical significance of these pleiotropic effects relative to the lipid-lowering effect remains a subject of ongoing investigation, but several large trials, most notably JUPITER, have suggested that the cardiovascular benefit of statin therapy extends to patients whose baseline low-density lipoprotein cholesterol is not markedly elevated.

## 3. Clinical Indications

Statins are indicated for both the primary and secondary prevention of atherosclerotic cardiovascular disease. The major guideline-endorsed indications can be summarised under four broad categories.

The first category comprises patients with established atherosclerotic cardiovascular disease, including those with prior myocardial infarction, ischaemic stroke or transient ischaemic attack of atherosclerotic origin, peripheral arterial disease, or stable angina. In these patients, high-intensity statin therapy is recommended unless contraindicated, with the goal of reducing low-density lipoprotein cholesterol by at least fifty per cent and, in current European guidelines, achieving an absolute level below 1.4 millimoles per litre, which corresponds to approximately 55 milligrams per decilitre.

The second category comprises patients with severe primary hypercholesterolaemia, defined as a low-density lipoprotein cholesterol level of 4.9 millimoles per litre or higher, which corresponds to approximately 190 milligrams per decilitre. These patients are at sufficiently elevated lifetime risk that statin therapy is recommended regardless of formal risk score, and many will require high-intensity treatment.

The third category comprises adult patients with diabetes mellitus, in whom statin therapy is recommended for those aged forty years and older, with intensity adjusted to the overall cardiovascular risk profile. Diabetes itself confers a substantially elevated risk of cardiovascular events, and the benefit of statin therapy in this population is well established.

The fourth category comprises patients without established disease but with elevated estimated ten-year cardiovascular risk according to validated risk equations such as the Pooled Cohort Equations used in the United States or the SCORE2 algorithm used in Europe. The threshold for initiating statin therapy varies between guidelines, but a ten-year risk of seven and a half per cent or higher is widely used in the United States as the threshold above which statin therapy should be discussed and, in most cases, initiated.

## 4. Dosing and Administration

Atorvastatin is available in oral tablets at strengths of ten, twenty, forty, and eighty milligrams. The recommended starting dose depends on the patient's baseline cardiovascular risk and the desired magnitude of low-density lipoprotein reduction. For patients requiring high-intensity therapy, atorvastatin is typically initiated at forty milligrams once daily and titrated to eighty milligrams once daily as tolerated. For patients requiring moderate-intensity therapy, atorvastatin is typically prescribed at ten to twenty milligrams once daily.

Atorvastatin may be taken at any time of day, with or without food. This contrasts with shorter-acting agents such as simvastatin, which are conventionally taken in the evening because endogenous cholesterol synthesis peaks during sleep. Atorvastatin's long half-life of approximately fourteen hours, and the considerably longer half-life of its active metabolites, render the timing of administration clinically unimportant.

Treatment with statins is generally lifelong. Discontinuation results in a return of low-density lipoprotein cholesterol to pre-treatment levels within several weeks and a corresponding loss of cardiovascular protection. Patients who discontinue statin therapy after an acute coronary syndrome have been shown in observational studies to experience higher rates of recurrent events compared to those who remain on therapy. Adherence to long-term statin therapy is therefore a major focus of secondary prevention efforts.

Dose adjustments are required in certain populations. In patients with severe renal impairment, particularly those receiving haemodialysis, lower doses of atorvastatin may be appropriate, although atorvastatin is largely cleared hepatically and is one of the more renally tolerant agents in the class. Concomitant use of certain medications that inhibit cytochrome P450 3A4, the principal metabolic pathway for atorvastatin, may necessitate dose reduction or substitution to avoid increased systemic exposure.

## 5. Contraindications

Statin therapy is contraindicated in three principal clinical situations.

The first absolute contraindication is active liver disease or unexplained persistent elevations of serum transaminases. Statins undergo extensive hepatic metabolism, and although clinically significant hepatotoxicity is rare, statin therapy should not be initiated in the presence of active hepatocellular disease. Mild and stable elevations of transaminases, including those associated with non-alcoholic fatty liver disease, do not constitute a contraindication, and several lines of evidence suggest that statin therapy may be beneficial in this population.

The second absolute contraindication is pregnancy. Cholesterol and its metabolites play essential roles in foetal development, and the use of statins during pregnancy has been associated with concerns regarding teratogenicity, although the absolute risk has been the subject of recent re-evaluation by regulatory agencies. Current guidelines continue to recommend that women of childbearing potential use effective contraception while on statin therapy and that statins be discontinued before a planned pregnancy. Statins are also contraindicated during breastfeeding.

The third absolute contraindication is known hypersensitivity to the specific statin or to any component of the formulation. Cross-reactivity between agents within the class is uncommon, and patients who experience hypersensitivity to one statin can frequently tolerate another.

A number of relative contraindications and cautions also apply. These include heavy alcohol use, a history of haemorrhagic stroke, severe renal impairment in the case of certain agents, and concomitant use of medications with significant interaction potential, particularly strong inhibitors of cytochrome P450 3A4 such as certain macrolide antibiotics, azole antifungals, and protease inhibitors.

## 6. Adverse Effects

The safety profile of statins has been extensively characterised through both randomised trials and large observational studies. The class is, on the whole, well tolerated, and the absolute rates of serious adverse events are low.

The most commonly reported adverse effect is muscle-related symptoms, which patients describe variably as myalgia, weakness, cramps, or stiffness. The reported incidence of muscle symptoms in observational studies is substantially higher than the incidence observed in blinded randomised trials, where rates of muscle symptoms are typically similar between statin and placebo arms. This discrepancy has been attributed in part to the nocebo effect, in which patients aware that they are taking a statin attribute non-specific symptoms to the medication. Nonetheless, a subset of patients does experience genuine statin-induced muscle symptoms, and management strategies include dose reduction, switching to a different agent, alternate-day dosing, or discontinuation in cases of significant intolerance.

Statin-induced myopathy, defined as muscle symptoms accompanied by elevations of serum creatine kinase, is uncommon. Rhabdomyolysis, the most severe form of muscle injury, is rare, with an incidence of fewer than one case per ten thousand patient-years of treatment for most agents at standard doses.

Hepatic adverse effects include transient and typically asymptomatic elevations of serum transaminases, which occur in a small percentage of patients and rarely progress to clinically significant liver injury. Routine monitoring of liver function tests beyond a baseline measurement is not currently recommended in the absence of symptoms.

Statins have been associated with a small absolute increase in the risk of new-onset diabetes mellitus, particularly in patients with pre-existing risk factors for diabetes such as obesity or metabolic syndrome. This risk is offset by the cardiovascular benefits of therapy, which are substantial even in patients who develop diabetes during treatment.

Less common adverse effects include cognitive complaints, although large-scale evidence does not support a causal link between statin use and clinically meaningful cognitive impairment, and the United States Food and Drug Administration removed cognitive impairment from the class labelling in 2018 following review of the evidence. Other rare adverse effects include peripheral neuropathy, sleep disturbance, and various skin reactions.

## 7. Drug Interactions

Atorvastatin is metabolised primarily by cytochrome P450 3A4. Drugs that strongly inhibit this enzyme increase atorvastatin exposure and the risk of dose-dependent adverse effects, particularly muscle toxicity. Clinically significant interactions occur with macrolide antibiotics such as clarithromycin and erythromycin, azole antifungals such as itraconazole and ketoconazole, certain protease inhibitors used in the treatment of HIV infection, and the immunosuppressant ciclosporin. Coadministration of atorvastatin with grapefruit juice in large quantities can also increase systemic exposure through inhibition of intestinal cytochrome P450 3A4.

Concomitant use of statins with fibrates, particularly gemfibrozil, increases the risk of myopathy through pharmacokinetic and pharmacodynamic interactions. Where combined therapy is considered necessary, fenofibrate is preferred over gemfibrozil because it lacks the most problematic interaction.

Statins do not have significant interactions with most antihypertensive agents, antiplatelet agents, or oral anticoagulants of the direct-acting class. The interaction with warfarin is modest and clinically manageable through standard monitoring of the international normalised ratio.

## 8. Monitoring

Before initiating statin therapy, a baseline lipid panel and measurement of liver enzymes are recommended. Measurement of creatine kinase is not routinely required in asymptomatic patients but should be performed in those with muscle symptoms or those at elevated risk of myopathy.

Following initiation, a follow-up lipid panel is typically performed after four to twelve weeks to assess response to therapy and adherence. Subsequent monitoring intervals depend on the clinical context but are generally annual or as clinically indicated. Liver function tests should be repeated if the patient develops symptoms suggestive of hepatic injury, such as unexplained malaise, jaundice, or right upper quadrant pain.

A poor response to therapy, defined as a smaller than expected reduction in low-density lipoprotein cholesterol, should prompt consideration of adherence issues, dietary factors, and, in selected cases, evaluation for secondary causes of dyslipidaemia such as hypothyroidism or nephrotic syndrome.

## 9. Conclusion

Statins are a cornerstone of modern cardiovascular prevention. Their efficacy in reducing the incidence of myocardial infarction, ischaemic stroke, and cardiovascular mortality is supported by an extensive evidence base spanning decades and including hundreds of thousands of randomised patients. Atorvastatin, available in doses of ten, twenty, forty, and eighty milligrams once daily, is among the most widely prescribed agents in the class and is suitable for both moderate-intensity and high-intensity therapy depending on the dose selected.

The principal contraindications to statin therapy are active liver disease, pregnancy and breastfeeding, and known hypersensitivity. The principal adverse effect of clinical concern is muscle symptoms, which are typically mild and reversible but which contribute substantially to discontinuation rates in real-world practice. The mechanism of action, competitive inhibition of hydroxymethylglutaryl-coenzyme A reductase with subsequent upregulation of hepatic low-density lipoprotein receptors, is well characterised and underpins both the lipid-lowering effect and the cardiovascular benefit of the class.

Effective use of statins in clinical practice depends on appropriate patient selection based on cardiovascular risk, choice of agent and dose appropriate to the desired intensity of low-density lipoprotein reduction, attention to drug interactions and contraindications, and sustained patient engagement to support long-term adherence. With these elements in place, statin therapy delivers one of the largest absolute benefits of any preventive intervention in adult medicine.
