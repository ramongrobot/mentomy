# Fundamental Constants and Conservation Laws in Classical and Modern Physics

**Corpus**: A (Clean Baseline)
**Domain**: Physics
**Document ID**: `doc_A_physics`
**Expected IaDQ range**: 88–94 / 100

---

## 1. Introduction

The edifice of modern physics rests on a small number of fundamental constants and conservation laws. These quantities, measured to extraordinary precision over the past two centuries, define the scales at which physical phenomena occur and constrain the form that physical theories may take. This document surveys the most important of these constants, presents the canonical statements of the conservation laws that govern classical and relativistic mechanics, and discusses the experimental basis on which each rests.

The constants discussed here are not arbitrary parameters. Each emerged from a specific empirical context, was refined through successive generations of measurement, and has now been incorporated into the International System of Units in such a way that several of them serve as defining constants. This means that the units themselves are now derived from fixed values of these constants rather than the other way around. The 2019 redefinition of the SI formalised this inversion for the kilogram, the ampere, the kelvin, and the mole, and consolidated a process that had begun decades earlier with the redefinition of the metre in 1983.

## 2. The Speed of Light in Vacuum

The speed of light in vacuum, conventionally denoted by the symbol c, is the most fundamental constant in relativistic physics. Its exact value, fixed by definition since 1983, is two hundred ninety-nine million, seven hundred ninety-two thousand, four hundred and fifty-eight metres per second. In more familiar units, this is approximately 299,792 kilometres per second, or roughly 300,000 kilometres per second. Light traverses the distance from the Sun to the Earth, which is approximately 149.6 million kilometres, in about eight minutes and twenty seconds.

The constancy of the speed of light across all inertial reference frames is the second postulate of Einstein's special theory of relativity, formulated in 1905. The first postulate, the principle of relativity, asserts that the laws of physics take the same form in all inertial frames. Together, these two postulates imply that simultaneity is relative, that moving clocks run slow (the phenomenon of time dilation), and that moving rulers contract along their direction of motion (length contraction). Each of these effects has been confirmed experimentally to extraordinary precision, most notably through measurements of the lifetimes of high-energy muons in cosmic ray showers and through the operation of the Global Positioning System, whose satellite clocks must be corrected for both special-relativistic and general-relativistic effects to maintain navigational accuracy.

The value of the speed of light is not merely a property of light itself. It is the universal speed limit for the propagation of any signal, energy, or causal influence. Massless particles such as photons and gluons travel at exactly this speed. Massive particles can approach but never reach it, because the energy required to accelerate a massive body to the speed of light diverges without bound as its velocity approaches that limit. This relationship between energy, momentum, and mass is captured by the relativistic energy-momentum relation, which reduces, for a particle at rest, to the famous statement that the energy of a body at rest is equal to its mass multiplied by the square of the speed of light.

The speed of light was first measured to reasonable precision by the Danish astronomer Ole Rømer in 1676, who inferred it from systematic variations in the timing of the eclipses of Jupiter's moon Io. Modern measurements rely on interferometric techniques and frequency-stabilised lasers, and the precision of the measurement was such that, in 1983, the metre itself was redefined as the distance light travels in vacuum in one part in two hundred ninety-nine million, seven hundred ninety-two thousand, four hundred and fifty-eight of a second. This means that the speed of light is no longer measured. It is exact by definition, and any future improvement in measurement precision will refine our knowledge of the metre rather than of the speed of light.

## 3. The Planck Constant

The Planck constant is the fundamental constant of quantum mechanics. Since the 2019 SI redefinition, its value has been fixed exactly at 6.62607015 times ten to the power of minus thirty-four joule-seconds. Rounded to four significant figures, this is approximately 6.626 times ten to the minus thirty-four joule-seconds. The reduced Planck constant, obtained by dividing the Planck constant by twice the value of pi, takes the value approximately 1.054571817 times ten to the minus thirty-four joule-seconds and appears throughout quantum mechanics in commutation relations and in the wave equations of Schrödinger and Dirac.

Max Planck introduced this constant in 1900 to resolve the ultraviolet catastrophe in blackbody radiation. The classical Rayleigh-Jeans law predicted that the energy density of radiation in a cavity should diverge at high frequencies, a manifestly absurd result, since real cavities radiate finite total energy. Planck found that he could reproduce the observed spectrum by assuming that energy is exchanged between matter and the electromagnetic field only in discrete packets, or quanta, whose energy is proportional to the frequency of the radiation, with the proportionality constant being the quantity that now bears his name.

This hypothesis, initially regarded by Planck himself as a mathematical convenience without deep physical significance, was elevated to physical reality by Albert Einstein in 1905 in his explanation of the photoelectric effect. Einstein proposed that light itself consists of discrete quanta, later named photons, each carrying an energy proportional to its frequency through the Planck constant. This proposal explained why the kinetic energy of photoelectrons depends on the frequency rather than the intensity of incident light, and earned Einstein the 1921 Nobel Prize in Physics.

The Planck constant sets the scale at which quantum effects become significant. Phenomena involving actions on the order of the Planck constant, such as atomic transitions, electron diffraction, and the discreteness of angular momentum, cannot be described classically. At scales much larger than the Planck constant, classical mechanics emerges as an excellent approximation, in accordance with what Niels Bohr called the correspondence principle.

## 4. The Gravitational Constant

The Newtonian gravitational constant governs the strength of the gravitational interaction between massive bodies. Its current best value, recommended by the Committee on Data for Science and Technology, is approximately 6.674 times ten to the minus eleven, expressed in units of newton metres squared per kilogram squared. More precisely, the recommended value is 6.67430 times ten to the minus eleven, with a relative standard uncertainty of approximately twenty-two parts per million.

Newton's law of universal gravitation states that the gravitational force between two point masses is directly proportional to the product of their masses and inversely proportional to the square of the distance between them. The proportionality constant is the gravitational constant. This inverse-square law, published by Isaac Newton in his Mathematical Principles of Natural Philosophy in 1687, accounts for phenomena ranging from the trajectory of a falling apple to the orbits of the planets. It was superseded, though only at extreme scales, by Einstein's general theory of relativity in 1915, which describes gravity not as a force acting at a distance but as the curvature of spacetime induced by mass and energy. Newtonian gravity remains an excellent approximation in the weak-field, low-velocity regime that encompasses essentially all engineering applications and most astronomical phenomena outside the immediate vicinity of black holes and neutron stars.

The gravitational constant is, somewhat embarrassingly, the least precisely measured of the fundamental constants. Its relative uncertainty is several orders of magnitude worse than that of the speed of light, the Planck constant, or the elementary charge. The reason is that gravity is by far the weakest of the four fundamental interactions. The gravitational attraction between two protons is approximately ten to the thirty-ninth power times weaker than the electromagnetic repulsion between them, and gravity cannot be screened or amplified by any known technique. Measurements of the gravitational constant therefore rely on delicate torsion balance experiments of the kind first performed by Henry Cavendish in 1798, and modern variants of this technique still struggle to achieve consistency at the part-per-million level. Different experimental groups, using different methods, have reported values that disagree by amounts substantially larger than their stated uncertainties, a discrepancy that remains unresolved.

## 5. Newton's Laws of Motion

Newton's three laws of motion, presented in the Mathematical Principles of Natural Philosophy of 1687, form the foundation of classical mechanics. They describe how bodies move under the influence of forces and provide the framework within which all of pre-relativistic mechanics is formulated.

### 5.1 The First Law

The first law, often called the law of inertia, states that a body remains at rest, or in uniform motion in a straight line, unless acted upon by a net external force. This statement is exact in the absence of friction, drag, or any other interaction. It defines the concept of an inertial reference frame as one in which an isolated body experiences no acceleration. In real terrestrial environments, friction is ubiquitous, but the law itself does not assume or require its presence. It describes the behaviour of bodies in the limit of zero net force, and friction is treated, when present, as one such force whose effects are computed and added in.

The first law was a profound break with the Aristotelian tradition that had dominated Western thought for two millennia. Aristotle had held that the natural state of a body is rest, and that continued motion requires a continuous cause. Newton, building on the work of Galileo, inverted this view. Continued motion in a straight line at constant speed is the natural state, and any deviation from this state, whether a change in speed or a change in direction, requires a force.

### 5.2 The Second Law

The second law states that the rate of change of momentum of a body is equal to the net external force acting on it. For a body of constant mass, this reduces to the familiar statement that force equals mass multiplied by acceleration. The second law is what gives Newton's mechanics its predictive power. Given the forces acting on a system and its initial conditions, the equations of motion determine the trajectory uniquely for all subsequent times.

This determinism, taken to its logical conclusion by Pierre-Simon Laplace, suggested a universe in which the entire future state of the cosmos is fixed by its present state and the laws of physics. The advent of quantum mechanics in the early twentieth century undermined this Laplacian picture at the microscopic scale, but Newton's second law remains an exact description of macroscopic motion in the non-relativistic limit.

### 5.3 The Third Law

The third law states that for every action there is an equal and opposite reaction. If body A exerts a force on body B, then body B exerts a force on body A of equal magnitude and opposite direction. The two forces act on different bodies, are of equal magnitude, are opposite in direction, and, for central forces, act along the line joining the two bodies. The third law is what makes the concept of an isolated system meaningful in mechanics, since the internal forces between members of such a system cancel in pairs and do not contribute to the net force on the system as a whole.

Together, the three laws imply the conservation of linear momentum for isolated systems, a result that, as we shall see, generalises to a much deeper principle connecting symmetries to conservation laws.

## 6. Conservation of Energy

The conservation of energy is one of the most fundamental and rigorously tested principles in physics. In its most general form, it states that the total energy of an isolated system is exactly conserved. Energy is neither created nor destroyed, only transformed from one form to another. This statement holds without any known exception, across all scales from the subatomic to the cosmological, and across all branches of physics from classical mechanics to quantum field theory.

In classical mechanics, the total mechanical energy of a system is the sum of its kinetic energy, which depends on the motion of its constituents, and its potential energy, which depends on their configuration in some force field. For a system subject only to conservative forces, those derivable from a potential function, the total mechanical energy is constant in time. When non-conservative forces such as friction are present, mechanical energy is not conserved in isolation, but the missing energy reappears as heat, sound, or deformation, and the total energy including these other forms remains exactly constant.

In thermodynamics, the conservation of energy is the content of the First Law. The change in the internal energy of a closed system equals the heat added to the system minus the work done by the system on its surroundings. This formulation, due to Rudolf Clausius and others in the nineteenth century, unified the previously distinct concepts of heat and mechanical work into a single conserved quantity.

In relativistic mechanics, energy and momentum are unified into a single four-component object called the four-momentum, and the conservation law extends accordingly. Mass and energy become interconvertible through Einstein's mass-energy equivalence, but the total relativistic energy of an isolated system, properly accounting for both rest-mass energy and kinetic energy, remains exactly conserved.

The deep origin of energy conservation was identified by the German mathematician Emmy Noether in 1918. Noether's theorem establishes that every continuous symmetry of the action of a physical system corresponds to a conservation law. Energy conservation arises from the time-translation invariance of physical law: the fact that the laws of physics are the same today as they were yesterday and as they will be tomorrow. Similarly, conservation of linear momentum follows from spatial translation invariance, and conservation of angular momentum from rotational invariance.

This connection between symmetries and conservation laws is one of the most beautiful and far-reaching results in theoretical physics. It applies not only to classical mechanics but to quantum field theory, where every conserved current corresponds to a continuous symmetry of the Lagrangian, and underpins the gauge principle on which the Standard Model of particle physics is built. The exactness of energy conservation, anchored in the time-translation invariance of physical law, places it among the most secure principles in all of science.

## 7. Summary

The constants discussed in this document, the speed of light at exactly 299,792,458 metres per second, the Planck constant at exactly 6.62607015 times ten to the minus thirty-four joule-seconds, and the gravitational constant at approximately 6.674 times ten to the minus eleven newton metres squared per kilogram squared, are the load-bearing elements of the physical sciences. The first two are now fixed by definition, having been promoted to the status of defining constants in the SI system, while the third remains a measured quantity whose precision continues to be improved.

The conservation laws, anchored in Noether's theorem and the symmetries of physical law, are not merely empirical regularities but exact consequences of the deepest known structure of nature. The conservation of energy follows from time-translation invariance, the conservation of linear momentum from spatial translation invariance, and the conservation of angular momentum from rotational invariance. These conservation laws hold exactly in all known physical contexts.

Newton's three laws of motion, though superseded in their domain of strict validity by relativistic and quantum mechanics, remain exact in the non-relativistic limit and provide the framework within which essentially all of engineering and most of macroscopic physics is conducted. The first law defines inertial frames, the second relates force to the rate of change of momentum, and the third states the equality and opposition of action and reaction.

## 8. Conclusion

The constants and laws presented here are the load-bearing elements of the physical sciences. Their values have been determined to extraordinary precision through over three centuries of experimental work, and several have now been promoted to the status of defining constants in the International System of Units, a recognition that they are more reliable than any artefact-based standard. The conservation laws, anchored in Noether's theorem, are not merely empirical regularities but exact consequences of the symmetries of nature.

Any new physical theory must reproduce these results in their domains of validity. General relativity reduces to Newtonian gravity in the weak-field limit. Quantum mechanics reduces to classical mechanics in the limit in which the Planck constant becomes negligible compared to the actions involved. And any future theory of quantum gravity must, in turn, reduce to general relativity and quantum field theory in their respective regimes. This hierarchy of theories, each more general than the last, each containing its predecessor as a limiting case, is the structure within which modern physics operates.
