# Plate Tectonics and the World's Major Mountain Ranges

**Corpus**: A (Clean Baseline)
**Domain**: Geography
**Document ID**: `doc_A_geography`
**Expected IaDQ range**: 88–94 / 100

---

## 1. Introduction

Plate tectonics is the unifying theory of modern geology. It describes the outer shell of the Earth as a mosaic of rigid plates that move relative to one another over a hotter, more ductile layer beneath, and it accounts for the global distribution of earthquakes, volcanoes, mountain ranges, ocean basins, and the long-term evolution of the continents themselves. Since its consolidation in the 1960s, the theory has provided the framework within which essentially all of structural geology, seismology, and large-scale geomorphology is now interpreted.

This document presents the principal elements of plate tectonic theory, surveys the major plates and the boundaries between them, and describes the formation, structure, and present-day characteristics of the world's most significant mountain ranges. The values and locations cited reflect the consensus of modern geological surveys, including the United States Geological Survey, the Geological Society of London, and the international scientific literature compiled in sources such as the Geologic Time Scale of the International Commission on Stratigraphy.

## 2. Historical Development of the Theory

The theory of plate tectonics did not emerge fully formed. Its principal predecessor was the hypothesis of continental drift, proposed by the German meteorologist and geophysicist Alfred Wegener in his 1915 book The Origin of Continents and Oceans. Wegener observed the close fit of the coastlines of South America and Africa, the distribution of identical fossils on continents now separated by oceans, and the alignment of geological features across continental margins, and he argued from this evidence that the present continents had once been joined in a single supercontinent, which he called Pangaea, and had subsequently drifted apart.

Wegener's hypothesis was largely rejected by the geological establishment of his time, principally because he could not propose a plausible mechanism by which the continents could plough through the rigid floors of the oceans. The hypothesis was rehabilitated in the 1950s and 1960s by a convergence of new evidence from oceanographic and geophysical research. Studies of the magnetic properties of basalts on either side of the mid-ocean ridges revealed symmetrical bands of alternating polarity, recording the periodic reversals of the Earth's magnetic field as new oceanic crust was generated at the ridge axis and carried outward. The work of Harry Hess, Robert Dietz, Frederick Vine, Drummond Matthews, and others established that the ocean floor is itself in motion, and that the continents are passive passengers carried along by this motion. By the late 1960s the theory of plate tectonics, which combined continental drift with sea-floor spreading and added the recognition that the rigid outer shell of the Earth is divided into a small number of large plates, had become the consensus view in the earth sciences.

## 3. The Structure of the Earth

The Earth is conventionally divided into a series of concentric layers distinguished by their composition and physical state. The outermost layer is the crust, which ranges in thickness from approximately five to ten kilometres beneath the oceans to as much as seventy kilometres beneath the highest mountain ranges. The crust is composed predominantly of silicate minerals and is chemically distinct from the underlying mantle. Continental crust is dominated by relatively low-density granitic rocks, while oceanic crust is dominated by denser basaltic rocks.

Beneath the crust lies the mantle, which extends to a depth of approximately 2,900 kilometres and constitutes the majority of the Earth's volume. The mantle is composed primarily of iron- and magnesium-rich silicate minerals, principally olivine and pyroxene in its upper portion. Although the mantle is solid in the geophysical sense, it deforms slowly under sustained stress and convects on geological timescales.

Beneath the mantle lies the core, which is divided into a liquid outer core and a solid inner core. The core is composed primarily of iron and nickel and is responsible, through fluid motion in the outer core, for generating the Earth's magnetic field through dynamo action.

For the purposes of plate tectonics, a different and more useful subdivision is employed. The lithosphere comprises the crust together with the uppermost portion of the mantle, forming a rigid layer typically 100 to 150 kilometres thick beneath the continents and somewhat thinner beneath the oceans. Beneath the lithosphere lies the asthenosphere, a region of the upper mantle in which the rocks, although still solid, are sufficiently ductile to flow on geological timescales. It is on the asthenosphere that the rigid plates of the lithosphere move.

## 4. The Major Plates

The lithosphere is divided into a small number of major plates and a larger number of smaller plates and microplates. The seven principal major plates, in approximate order of size, are the Pacific Plate, the African Plate, the North American Plate, the Eurasian Plate, the Antarctic Plate, the Australian Plate, and the South American Plate. Several substantial secondary plates, including the Nazca Plate beneath the eastern Pacific, the Indian Plate, the Arabian Plate, the Philippine Sea Plate, the Caribbean Plate, the Cocos Plate, the Scotia Plate, and the Juan de Fuca Plate, complete the global tectonic picture.

The boundaries between plates are the locus of nearly all of the world's earthquakes and active volcanoes. They are conventionally classified into three principal types: divergent boundaries, where two plates move apart; convergent boundaries, where two plates move toward one another; and transform boundaries, where two plates slide past one another horizontally.

## 5. Plate Boundaries

### 5.1 Divergent Boundaries

At divergent boundaries, two plates move apart and new lithosphere is created in the gap between them through the upwelling of magma from the asthenosphere. The most extensive divergent boundaries lie along the mid-ocean ridge system, a continuous submarine mountain chain that traverses every ocean basin and totals approximately sixty-five thousand kilometres in length. The Mid-Atlantic Ridge, which separates the North American and Eurasian plates in the north and the South American and African plates in the south, is the type example. Iceland, situated directly atop the Mid-Atlantic Ridge, is one of the few places where this normally submarine boundary is exposed above sea level, allowing direct observation of the rifting process.

Spreading rates at mid-ocean ridges vary considerably. The slow-spreading Mid-Atlantic Ridge separates at a rate of approximately two to four centimetres per year, while the fast-spreading East Pacific Rise separates at rates of up to fifteen centimetres per year. These rates, modest by everyday standards, are nonetheless sufficient to open an entire ocean basin in the course of one to two hundred million years.

Continental rifting, the process by which a continent is split apart to form a new ocean basin, also occurs at divergent boundaries. The East African Rift Valley, which runs from the Afar Triangle in the north through Kenya, Tanzania, and Mozambique, is the world's most extensive active continental rift and represents the early stages of a process that may, over the next several tens of millions of years, separate the Horn of Africa from the rest of the continent.

### 5.2 Convergent Boundaries

At convergent boundaries, two plates move toward one another and one of the two is typically forced beneath the other in a process known as subduction. The geometry of subduction depends on the nature of the converging plates. Where oceanic lithosphere converges with continental lithosphere, the denser oceanic plate is subducted beneath the lighter continental plate, producing a trench at the surface and an arc of volcanoes inland from the trench. The Andes mountain range along the western margin of South America is the type example of this configuration, with the Nazca Plate being subducted beneath the South American Plate at the Peru–Chile Trench.

Where two oceanic plates converge, one is subducted beneath the other, producing an island arc such as the Aleutian Islands, the Kuril Islands, the Marianas, or the islands of Japan. The Mariana Trench, the deepest known point in the world's oceans at approximately 11,000 metres below sea level, marks the subduction of the Pacific Plate beneath the Philippine Sea Plate.

Where two continental plates converge, neither is dense enough to be subducted readily, and the result is a continent-continent collision in which the crust is thickened and folded into a major mountain range. The Himalaya, formed by the collision of the Indian Plate with the Eurasian Plate beginning approximately 50 million years ago and continuing today, is the type example of this configuration.

### 5.3 Transform Boundaries

At transform boundaries, two plates slide past one another horizontally without either being created or destroyed. The most famous transform boundary is the San Andreas Fault in California, which marks the boundary between the Pacific Plate and the North American Plate over a length of approximately 1,200 kilometres. The Pacific Plate is moving northwestward relative to the North American Plate at a rate of approximately five centimetres per year, accumulating elastic strain that is periodically released in earthquakes. The Anatolian Fault in Turkey, the Alpine Fault in New Zealand, and the Dead Sea Transform are other major examples.

## 6. The World's Major Mountain Ranges

### 6.1 The Himalaya

The Himalaya are the highest mountain range in the world. They extend for approximately 2,400 kilometres along the southern margin of the Tibetan Plateau, from the Nanga Parbat massif in the west to Namcha Barwa in the east, and are shared among the territories of Pakistan, India, China, Nepal, and Bhutan. The range contains all fourteen of the world's mountains exceeding 8,000 metres in elevation, of which the highest is Mount Everest, known in Nepali as Sagarmatha and in Tibetan as Chomolungma, with a recognised height of 8,848.86 metres above sea level following the joint Nepal-China survey of 2020. The second-highest peak in the world, K2, is not in the Himalaya proper but in the adjacent Karakoram range, with a height of 8,611 metres.

The Himalaya were formed, and continue to be formed, by the collision of the Indian Plate with the Eurasian Plate. The Indian Plate, having separated from the supercontinent of Gondwana during the Cretaceous period, drifted northward across the Tethys Ocean over tens of millions of years before colliding with Eurasia approximately 50 million years ago. The Indian Plate continues to move northward at a rate of approximately five centimetres per year, and the Himalaya continue to rise at a rate of several millimetres per year, although erosion offsets much of this uplift.

### 6.2 The Andes

The Andes are the longest continental mountain range in the world, extending approximately 7,000 kilometres along the western margin of South America from Venezuela in the north to the southern tip of Chile and Argentina. The highest peak in the Andes, and the highest mountain outside Asia, is Aconcagua in Argentina, at 6,961 metres above sea level. The Andes are characterised by extensive volcanism, with active volcanoes distributed along most of the range, and by frequent and sometimes catastrophic earthquakes.

The Andes are the product of the subduction of the Nazca Plate beneath the South American Plate, a process that has been active since at least the late Mesozoic. The convergence rate is approximately seven centimetres per year. The Peru-Chile Trench, which marks the surface expression of the subduction zone, reaches depths in excess of 8,000 metres at its deepest point.

### 6.3 The Rocky Mountains

The Rocky Mountains extend approximately 4,800 kilometres along the western interior of North America, from British Columbia in the north to New Mexico in the south. The highest peak in the Rocky Mountains is Mount Elbert in Colorado, at 4,401 metres above sea level. The Rockies are the product of a complex sequence of orogenic events, of which the most important is the Laramide orogeny, which occurred between approximately 80 million and 55 million years ago and was driven by the unusually shallow-angle subduction of the Farallon Plate beneath the western margin of North America.

### 6.4 The Alps

The Alps form a curved arc approximately 1,200 kilometres in length across central and southern Europe, traversing France, Switzerland, Italy, Austria, Germany, Slovenia, and several other states. The highest peak is Mont Blanc, on the Franco-Italian border, at 4,808 metres above sea level. The Alps were formed by the collision of the African Plate with the Eurasian Plate, a process that began in the Cretaceous period and continued through the Cenozoic. The closure of the Tethys Ocean and the subsequent collision uplifted the marine sediments that had accumulated in that ocean basin and folded them into the complex thrust-and-nappe structure that characterises the Alps today.

### 6.5 The Appalachians

The Appalachian Mountains extend approximately 2,400 kilometres along the eastern interior of North America. The highest peak is Mount Mitchell in North Carolina, at 2,037 metres above sea level. The Appalachians are an ancient range, formed by a series of orogenic events between approximately 480 million and 270 million years ago, culminating in the collision of North America with Africa during the assembly of the supercontinent Pangaea. Erosion over the subsequent 250 million years has reduced what was once a Himalayan-scale range to its present, much-diminished elevations.

### 6.6 The Ural Mountains

The Urals extend approximately 2,500 kilometres in a roughly north-south direction across western Russia and are conventionally regarded as the boundary between Europe and Asia. The highest peak is Mount Narodnaya, at 1,895 metres above sea level. The Urals were formed by the collision of the Siberian and East European cratons during the assembly of Pangaea in the late Palaeozoic, between approximately 320 million and 250 million years ago. Like the Appalachians, they are an ancient range that has been substantially reduced by erosion.

## 7. Earthquakes and Volcanism

The vast majority of the world's earthquakes and volcanoes occur at or near plate boundaries. The Pacific Ring of Fire, a roughly horseshoe-shaped zone encircling the Pacific Ocean basin, hosts approximately seventy-five per cent of the world's active and dormant volcanoes and is the site of approximately ninety per cent of the world's earthquakes. The Ring of Fire traces the boundaries of the Pacific Plate and the smaller plates that abut it, including the subduction zones along the Andes, Central America, the Aleutians, Japan, the Philippines, and New Zealand.

Earthquake magnitudes are conventionally measured using the moment magnitude scale, which has largely replaced the earlier Richter scale for events larger than approximately magnitude 6. The largest instrumentally recorded earthquake was the Great Chilean Earthquake of 22 May 1960, which had a moment magnitude of 9.5. Other major recent earthquakes include the Sumatra earthquake of 26 December 2004, magnitude 9.1, which generated the Indian Ocean tsunami, and the Tōhoku earthquake of 11 March 2011 in Japan, magnitude 9.1.

## 8. Conclusion

Plate tectonics provides a unified framework within which the major features of the Earth's surface, including its mountain ranges, ocean basins, volcanoes, and earthquake zones, can be understood as manifestations of a single underlying process: the slow horizontal motion of rigid lithospheric plates over a ductile asthenosphere. The world's great mountain ranges, from the still-rising Himalaya to the eroded Appalachians, record the history of plate convergence and continental collision over hundreds of millions of years, and the ongoing motion of the plates ensures that the geography of the planet, while stable on human timescales, continues to evolve on the timescales of geological history. The next several tens of millions of years will see the East African Rift open into a new ocean, the Mediterranean close as Africa continues to converge with Eurasia, and Australia continue its northward drift toward Asia. The map of the world is not fixed, only slow.
