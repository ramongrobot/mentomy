# Query Set for Corpus Entropy Evaluation

**Dataset**: Corpus Entropy Benchmark (Mentomy AI)
**Purpose**: A 25-query evaluation set, stratified by query type, designed to probe the relationship between Corpus Entropy (CE = IaDNI ⊕ IeDCD) and Answer Confidence Score (ACS) under controlled conditions across the four corpora (A, B, C, D).

**Stratification**:
- 10 **conflicted-variable** queries — directly target an (entity, relation) pair injected as a conflict in Corpus B / D
- 10 **non-conflicted** queries — target facts that are consistent across all corpora; ACS should remain high even in Corpus B
- 5 **structurally-degraded** queries — require synthesis across multiple passages, sensitive to IaDNI; should be answerable from Corpus A but difficult from Corpus C

**Field schema (per query)**:
- `query_id` — short identifier
- `query_text` — natural-language question as posed to the RAG pipeline
- `query_type` — `conflicted_variable` / `non_conflicted` / `structurally_degraded`
- `domain` — physics / medicine / history / geography / biology
- `target_entity` — the entity the query is about
- `target_relation` — the (entity, relation) pair being probed
- `correct_answer` — the answer grounded in Corpus A
- `conflicting_answer` — the contradicting answer grounded in Corpus B (where applicable; `null` for non-conflicted queries)
- `linked_conflict_id` — pointer to the Ground Truth Conflict Map (where applicable; `null` otherwise)
- `expected_acs_degradation` — corpus condition expected to degrade ACS most
- `notes` — methodological commentary

---

## 1. Conflicted-Variable Queries (10)

These queries directly target an injected conflict. The pipeline must retrieve evidence from a corpus containing the conflict (B or D) and produce an ACS that reflects the conflicting evidence. ACS in Corpus A should remain high; ACS in Corpus B and D should drop substantially as the chunk window includes both the correct and the injected value.

| query_id | query_text | domain | target_entity | target_relation | correct_answer | conflicting_answer | linked_conflict_id | expected_acs_degradation |
|---|---|---|---|---|---|---|---|---|
| Q01 | What is the speed of light in vacuum? | physics | speed of light in vacuum | value | 299,792,458 m/s (≈ 299,792 km/s) | ≈ 250,000 km/s | P1 | Corpus B and D (conflict-only and combined) |
| Q02 | What is the value of the Planck constant? | physics | Planck constant | value | 6.62607015 × 10⁻³⁴ J·s | 6.200 × 10⁻³⁴ J·s | P2 | Corpus B and D |
| Q03 | Is the conservation of energy exact or approximate in modern physics? | physics | conservation of energy | precision/qualifier | exactly conserved (consequence of Noether's theorem and time-translation invariance) | approximately conserved over typical timescales | P5 | Corpus D combined (compounds with structural degradation) |
| Q04 | How long is statin therapy typically continued? | medicine | statin therapy | duration | typically lifelong; discontinuation reverses cardiovascular protection | typically 1–3 years, then reassessed | M4 | Corpus B and D |
| Q05 | What is the mechanism by which statins lower LDL cholesterol? | medicine | statin mechanism of action | downstream effect on hepatic LDL receptors | upregulation of hepatic LDL receptors → increased clearance of circulating LDL-C | downregulation of LDL receptors → reduced VLDL synthesis | M1 | Corpus B and D |
| Q06 | On what date was Louis XVI executed? | history | Execution of Louis XVI | date | 21 January 1793 | 28 January 1793 | H5 | Corpus B and D |
| Q07 | When did the coup of 18 Brumaire take place? | history | Coup of 18 Brumaire | date (Gregorian) | 9 November 1799 | 18 November 1799 | H1 | Corpus B and D |
| Q08 | Who wrote *Reflections on the Revolution in France* (1790)? | history | Reflections on the Revolution in France | author | Edmund Burke | Joseph de Maistre | H9 | Corpus B and D |
| Q09 | What is the elevation of Aconcagua? | geography | Aconcagua | elevation | 6,961 m | 6,400 m | G7 | Corpus B and D |
| Q10 | What does the T wave on the electrocardiogram represent? | biology | T wave on the electrocardiogram | reflects | ventricular repolarisation | atrial repolarisation | B6 | Corpus D combined (mechanism inversion compounds with terminology drift) |

### Difficulty distribution within conflicted-variable subset

- **Easy** (Q01, Q02, Q06, Q07, Q09): direct numerical or date conflicts where retrieval should surface both versions; tests whether the contradiction-detection module can detect a clear two-value disagreement.
- **Medium** (Q04, Q08): require entity-relation reasoning rather than passage-level overlap; the conflict is on a duration claim or an attribution.
- **Hard** (Q03, Q05, Q10): mechanism/qualifier conflicts where the surface text is similar but the meaning differs. These are the conflicts most likely to fool a naive retrieval-and-quote pipeline and on which a properly grounded RAG system should appropriately flag low confidence.

---

## 2. Non-Conflicted Queries (10)

These queries target facts that are consistent across all four corpora. There is no injected conflict for the (entity, relation) pair, so a well-functioning pipeline should produce a high-confidence answer regardless of corpus condition. These queries serve as the **control set**: any drop in ACS from Corpus A to Corpus B, beyond statistical noise, would indicate that conflict-injected documents in adjacent contexts are corrupting answers to unrelated queries — a phenomenon worth measuring and reporting.

| query_id | query_text | domain | target_entity | target_relation | correct_answer | linked_conflict_id | expected_acs_degradation |
|---|---|---|---|---|---|---|---|
| Q11 | What was Newton's first law of motion called by historians? | physics | Newton's first law | alternative name | the law of inertia | null | Corpus C and D combined (high-IaDNI degrades retrieval) |
| Q12 | In what year did Einstein receive the Nobel Prize, and for what work? | physics | Einstein, Nobel Prize | year and reason | 1921, for his explanation of the photoelectric effect | null | Corpus C and D combined (truncation may remove the answer in some doc variants) |
| Q13 | Which class of drugs are HMG-CoA reductase inhibitors most commonly known as? | medicine | HMG-CoA reductase inhibitors | colloquial class name | statins | null | Minimal expected degradation (consistent across all corpora) |
| Q14 | Where is the sinoatrial node located in the human heart? | biology | sinoatrial node | anatomical location | in the wall of the right atrium near the entry of the superior vena cava | null | Corpus C and D combined (terminology drift may mask answer) |
| Q15 | What does the QRS complex on an electrocardiogram reflect? | biology | QRS complex | physiological event | ventricular depolarisation | null | Minimal expected degradation |
| Q16 | What is the largest mountain range in the world by length? | geography | longest continental mountain range | identification | the Andes (approximately 7,000 km along western South America) | null | Corpus C and D combined |
| Q17 | Which fortress was stormed in Paris on 14 July 1789? | history | event of 14 July 1789 | location | the Bastille | null | Corpus C and D combined |
| Q18 | What is the deepest known point in the world's oceans, and what plate boundary does it mark? | geography | Mariana Trench | depth and tectonic context | approximately 11,000 m below sea level; marks the subduction of the Pacific Plate beneath the Philippine Sea Plate | null | Corpus C and D combined |
| Q19 | What is the function of the Frank-Starling mechanism? | biology | Frank-Starling mechanism | function | within physiological limits, the greater the volume of blood entering the heart during diastole, the greater the volume ejected during the subsequent systole | null | Corpus B and D conflict (note: the *attribution* of the mechanism is a conflict — B5 — but its function is not) |
| Q20 | What does the Pacific Ring of Fire host, in proportional terms? | geography | Pacific Ring of Fire | composition | approximately 75% of the world's active and dormant volcanoes; ~90% of the world's earthquakes | null | Corpus C and D combined |

### Methodological note on Q19

This query is included deliberately to probe a subtle phenomenon: when a fact (the *function* of Frank-Starling) is non-conflicted but lies adjacent in the corpus to a conflicted fact (the *attribution* of the mechanism — B5: Starling vs. Bayliss), the pipeline may produce a degraded ACS for the non-conflicted query as a side effect of the nearby conflict. Tracking ACS for Q19 across corpora gives a measure of **conflict spillover**, which is itself a phenomenon worth reporting in the *Information Fusion* paper.

---

## 3. Structurally-Degraded Queries (5)

These queries require synthesis across multiple passages and are therefore sensitive to IaDNI rather than to IeDCD. They should be answerable from Corpus A (well-structured prose), difficult from Corpus C (degraded prose with truncation, repetition, irrelevant content, and broken cross-references), and intermediate in Corpora B and D depending on whether the relevant passages have been retained or truncated. No injected conflicts target these queries.

| query_id | query_text | domain | target_entity | target_relation | correct_answer | linked_conflict_id | expected_acs_degradation |
|---|---|---|---|---|---|---|---|
| Q21 | According to the document, what is the connection between Noether's theorem and the conservation laws of physics? | physics | Noether's theorem | implication for conservation laws | Noether's theorem establishes that every continuous symmetry of the action of a physical system corresponds to a conservation law: time-translation invariance gives energy conservation, spatial translation invariance gives linear momentum conservation, rotational invariance gives angular momentum conservation | null | Corpus C and D structural/combined (synthesis across §6 sections; truncation of physics doc removes the energy-conservation discussion entirely in some variants) |
| Q22 | Summarise the four guideline-endorsed indications for statin therapy in adults. | medicine | statin therapy | clinical indications (multi-part synthesis) | (1) established atherosclerotic cardiovascular disease, (2) severe primary hypercholesterolaemia (LDL ≥ 4.9 mmol/L), (3) diabetes mellitus in adults aged ≥ 40 years, (4) elevated estimated 10-year cardiovascular risk (≥ 7.5% in US guidelines) | null | Corpus C and D structural/combined (truncated medicine doc may drop categories 3–4 entirely) |
| Q23 | What is the chronological sequence of major political events from the storming of the Bastille to the fall of Robespierre? | history | French Revolution chronology | event sequencing (multi-event synthesis) | (1) Bastille, 14 July 1789; (2) Abolition of feudalism, 4 August 1789; (3) Declaration of the Rights of Man, 26 August 1789; (4) Flight to Varennes, 20–21 June 1791; (5) Storming of the Tuileries, 10 August 1792; (6) Proclamation of the Republic, 21 September 1792; (7) Execution of Louis XVI, 21 January 1793; (8) Reign of Terror under Committee of Public Safety, 1793–1794; (9) Fall of Robespierre, 27 July 1794 | null | Corpus C and D structural/combined (formatting removal in history doc collapses chronology into a continuous block; key dates remain present but require synthesis from undifferentiated prose) |
| Q24 | What are the three principal types of plate boundary, and what mountain or feature exemplifies each? | geography | plate boundary taxonomy | classification + example synthesis | (1) divergent — Mid-Atlantic Ridge / mid-ocean ridge system; (2) convergent — the Andes (oceanic-continental), Marianas (oceanic-oceanic), Himalaya (continental-continental); (3) transform — San Andreas Fault | null | Corpus C and D structural/combined (truncation of geography doc may remove transform boundaries section; inconsistent terminology — "rigid shell"/"soft layer" — fragments retrieval) |
| Q25 | Describe the cardiac cycle from atrial systole through ventricular diastole, including the volume changes in each ventricle. | biology | cardiac cycle | sequential physiological synthesis | atrial systole (final filling) → isovolumetric ventricular contraction → ejection (≈ 70 mL ejected, leaving ≈ 50 mL end-systolic volume from ≈ 120 mL end-diastolic volume) → isovolumetric relaxation → rapid filling → slow filling, completed by next atrial systole | null | Corpus C and D structural/combined (paragraph repetition and irrelevant historical content in the biology doc forces the pipeline to synthesise from a noisy block) |

---

## 4. Predicted Outcome Matrix

The expected pattern of ACS degradation across the four corpora — the central empirical prediction of the paper — is summarised below. Numerical entries are *predicted* qualitative levels (H = High, M = Medium, L = Low) based on the dataset design; actual values will be measured by the pipeline.

| Query type | Corpus A | Corpus B | Corpus C | Corpus D |
|---|---|---|---|---|
| Conflicted-variable (Q01–Q10) | **H** | **L** (conflict surfaces) | M–H (no conflict but degraded retrieval) | **L** (compounded) |
| Non-conflicted (Q11–Q20) | **H** | **H** (no relevant conflict) | M (degraded retrieval) | M (degraded retrieval; minor spillover) |
| Structurally-degraded (Q21–Q25) | **H** | **H** (clean structure) | **L** (degraded structure) | **L** (compounded) |

The predicted differential — namely that **Corpus D combined documents produce the lowest ACS for conflicted-variable and structurally-degraded queries, while non-conflicted queries degrade only modestly even in adversarial conditions** — is the testable quantitative claim of the paper. Departures from this pattern (in particular, ACS drops for non-conflicted queries that exceed the baseline measurement noise) would indicate conflict spillover and should be reported as a secondary finding.

---

## 5. Notes on Use

- **Retrieval scope**: queries should be evaluated under each corpus condition independently. The pipeline retrieves only from the documents in the corpus under test.
- **ACS measurement**: the primary endpoint per query is the Answer Confidence Score; secondary endpoints include $RS_1$ (top-1 retrieval similarity), $RS_\mu$, $RS_\sigma$, and a binary judgement of factual correctness against the `correct_answer` field.
- **Per-corpus reporting**: report ACS per query per corpus condition. The aggregate plot (CE on x-axis, mean ACS on y-axis, faceted by query type) is the headline figure of the paper.
- **Statistical analysis**: with 25 queries × 4 corpora = 100 evaluation points per pipeline configuration, paired statistical tests (e.g., Wilcoxon signed-rank between Corpus A and Corpus D) provide adequate power for the claimed effect sizes.

---

## 6. CSV Export

A machine-readable CSV version of the query set is provided as `query_set.csv` in the same directory.

---

**End of Query Set**
